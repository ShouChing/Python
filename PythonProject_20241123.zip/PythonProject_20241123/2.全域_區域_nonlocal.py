# 全域、區域變數
# 區域變數、全域變數設為相同，會造成混亂
fruit = 'Orange'            # global變數
def Demo():
    global fruit            # 需要用global化解
    print('最愛的水果', fruit)
    fruit = 'Watermelon'    # 改變全域的值
    print('夏天水果', fruit)
print(fruit) # 呼叫函數前
Demo()
print(fruit) # 呼叫函數後

# nonlocal: 內部函數需要修改外部函數的變數才需要使用
# def allNums(total):          # 定義函式
#     def oneFun(item, step):  # 定義函式的函式
#         nonlocal total
#         print('數值:', end = '')
#         for item in range(1, item + 1, step):
#             print(f'{item:3d}', end = '')
#             total += item    # total有被修改需要用nonlocal
#         print()
#         return total         # 回傳加總結果
#     return oneFun            # 回傳函式物件
# star = allNums(0)            # total = 0, 呼叫函式
# # 呼叫函式oneFun，變數star配合range(1, 20, 3)函式做加總
# print('合計:', star(20, 3))
