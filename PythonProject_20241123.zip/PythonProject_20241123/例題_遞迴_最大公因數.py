def compute(a, b):
    q1, q2 = divmod(a, b)
    if q2 == 0:
        return print(b)
    compute(b, q2)
data = input()
x, y = map(int, data.split(","))
compute(x, y)

# 遞迴練習 最大公因數
# x = eval(input("請輸入正整數:"))
# y = eval(input("請輸入正整數:"))
# def compute(x, y):
#     if x > y:
#         d1, d2 = divmod(x, y)
#         q = y, d2
#     else:
#         d1, d2 = divmod(y, x)
#         q = x, d2
#     if d2 != 0:
#         return compute(*q)
#     else:
#         return y
# print(compute(x, y))

# 函數迴圈練習 最大公因數
# x = eval(input("請輸入正整數:"))
# y = eval(input("請輸入正整數:"))
# def compute(x, y):
#     while True:
#         if x > y:
#             d1, d2 = divmod(x, y)
#             x, y = y, d2
#         else:
#             d1, d2 = divmod(y, x)
#             x, y = x, d2
#         if d2 == 0:
#             return x
# print(f'x和y的最大公因數為{compute(x, y)}')