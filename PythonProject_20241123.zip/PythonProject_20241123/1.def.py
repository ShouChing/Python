# 預設參數
def add_value_to_list_default(old_list, default_value = "New_Value", the_value=None):
    old_list.append(default_value)
    if the_value is not None:
        old_list.append(the_value)
list1 = [2, 5 ,7, 66, 87, 65, 101, 45, 28, 61]
add_value_to_list_default(list1)
print(list1)
add_value_to_list_default(list1, "My_Value", "New_Value")
print(list1)

# 關鍵字引數%預設
string1 = "ABC"
a, b, c = 100, 200, 10.123
def add_many_value(str1, int1, int2, float1):
    return int1 + int2 + float1
add_many_value(int1=a, float1=c, str1=string1, int2=b)
