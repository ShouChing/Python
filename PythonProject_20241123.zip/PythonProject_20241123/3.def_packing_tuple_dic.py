# tuple packing
# def sum_score(score1, score2, score3, *all_score):
#     print(type(all_score))
#     total = score1 + score2 + score3
#     for item in all_score:
#         total += item
#     return total
# print(sum_score(67, 87, 71))
# print(sum_score(67, 87, 71,85,93,45))

# dictionary packing
def score(**value):   # 定義函式，**收集關鍵字引數
    print(type(value))
    print('成績', value)
    for k, v in value.items():
        print(f"科目={k}, 成績={v}")
score(eng = 52, comp = 93, math = 62)   # 呼叫函式
# 輸出 成績 {'eng': 52, 'comp': 93, 'math': 62}(字典物件)

# *Packing & *Unpacking
# def student(*score):   # 函式一
# def student(score):
#      return sum(score)
# # 第二個函式，三個參數，第2個以函式為物件，第3個接收多個引數
# def getScore(name, func, *one):
#      print(name, '總分:', end = '')
#      return func(one)
#      # return func(*one)  # 回傳函式及參數
# # 呼叫第二個函式
# print(getScore('Tomas', student, 78, 65, 92))