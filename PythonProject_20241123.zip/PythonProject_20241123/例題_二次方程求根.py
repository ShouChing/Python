def compute(a, b, c):
    delta = b**2-4*a*c
    if delta > 0:
        root1 = (-b + delta ** 0.5) / (2 * a)
        root2 = (-b - delta ** 0.5) / (2 * a)
        print(f'{root1}, {root2}')
    elif delta == 0:
        root = -b / (2 * a)
        print(root)
    else:
        print("Your equation has no root.")
a = eval(input())
b = eval(input())
c = eval(input())
compute(a, b, c)