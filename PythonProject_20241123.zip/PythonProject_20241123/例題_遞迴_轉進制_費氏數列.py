# 費氏數列 1,1 小於num的數列
def fiboA(num):
    result = []   # 儲存費氏數列
    a, b = 0, 1
    while b < num:
        result.append(b)
        a, b = b, a + b
    return result
print('Fibonacci:', fiboA(20))   # 呼叫函式

# 費氏數列 1,1 n個數字的陣列
n = eval(input("請輸入數字:"))
list = [1,1]
for i in range(n-2):
    c = list[i] + list[i+1]
    list.append(c)
print(list)

# 費氏數列 1,1 的第n個數字
n = eval(input("請輸入數字:"))
a = b = 1
# 前兩輪被省略，使第一二輪結果為1, 1
for i in range(3,n+1):
    a, b = b, a+b
print(b)

# 費氏數列 0,1
# def compute(n):
#     a, b = 0, 1
#     print(f'{a} {b}', end=" ")
#     for i in range(n-2):
#         a, b = b, a+b
#         print(b,end=" ")
#     else: print()
# n = eval(input())
# compute(n)

# 費氏數列 遞迴 0,1
# def fibon(x):
#      if x <= 1:                            # 基本情況
#         return x
#      else:
#         return fibon(x - 1) + fibon(x - 2) # 遞廻情況
# outcome = []   # 空串列
# for item in range(10):
#     outcome.append(fibon(item))
# print('遞廻:', outcome)

# 遞迴 轉進制
# num = eval(input("請輸入數字:"))
# carry = eval(input("要轉成幾進制?"))
# def operate(x, y):
#     if x//y == 0:
#         return print(x%y,end="")
#     operate(x//y, y)   # 跑到終止條件跳出來後，
#     print(x%y, end="") # 繼續執行完整個def再跳回去，因為沒有第二個return
# operate(num,carry)     # 不用return，執行完整個def也會跳回上一層
#
# def gcd(m,n):
#     if m<n:
#         print(m,end="")
#     else:
#         gcd(m//n, n)
#         print(m%n,end="")
# gcd(num,carry)
