# TODO
def compute(p,q):
    q1, q2 = divmod(p,q)
    if q2 == 0:
        return q
    return compute(q,q2)
x, y = map(int,input().split(","))
m, n = map(int,input().split(","))
p, q = x*n+m*y, y*n
maxi = compute(p,q)
print(f'{x}/{y} + {m}/{n} = {int(p/maxi)}/{int(q/maxi)}')
