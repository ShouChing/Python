# TODO
def compute(x):
    if x in [2,3,5,7]:
        return "Prime"
    if x <= 1 or not x % 2 or not x % 3 or not x % 5 or not x % 7:
        return "Not Prime"
    i = 11
    while x >= i*i:
        if not x % i:
            return "Not Prime"
        i += 1
    return "Prime"
x = eval(input())
print(compute(x))
"""
Prime
Not Prime
"""