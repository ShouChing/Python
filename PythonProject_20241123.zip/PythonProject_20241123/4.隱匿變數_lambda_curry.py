# # 隱匿變數
# _, mod_v = divmod(100, 3) # 36...1
# # print(div_v, mod_v)
# print(mod_v)
# print()

# lambda跟.sort()結合
'''.sort()比較元組大小，先比較第一項第一個元素，若相同則後往後比較，
若第一項都相同，則比較第二項'''
# 依照出生年排序由大到小，若出生年相同，就用名稱排序由小到大
# pern = [('Mary', 1987, 'Taipei'),
#         ('Davie', 1988, 'Kaohsiung'),
#         ('Andy', 1988, 'Taichung'),
#         ('Monica', 1987, 'Hsinchu'),
#         ('Cindy', 1987, 'Taipei')]
# st = lambda item: (-item[1],item[0])
# # st = lambda item: str(item[1]) + item[0]
# # 數字加上負號，整個顛倒
# pern.sort(key = st)
# print('依出生年排序：')
# for i in pern:
#     print('{:6s},{}, {:10s}'.format(*i))
# # print(('Cindy', 1987)>('Andy', 1988))

# 鞣製(Curry): 把多參數函數變成單參數函數，目的結合lambda
# 先代5->num1=5，再return出來代3進去->num2=3
# def Outer(num1):
#    def Inner(num2):
#       return num1 ** num2
#    return Inner           # 沒引數
# result = Outer(5)(3)      # 125
# print(result)
#
# def exter(x, y):
#     def internal(a, b):
#         #BIF divmod() a//b, a % b
#         return divmod(x/a, y/b)
#     return internal
# print(exter(25, 7)(5,1))

# closure
# def exter(x, y):
#     def internal(a, b):
#         #BIF divmod() a//b, a % b
#         return divmod(a, b)
#     return internal(x, y)
# print(exter(25, 7))       # 3...4
