f_name = input()
str_old = input()
str_new = input()
#TODO
list1 = []
print("=== Before the replacement")
#TODO
with open(f_name,"r") as file:
    fr = file.read()
    print(fr)
for i in fr.split("\n"):
    if str_old in i:
        i = i.replace(str_old,str_new)
    list1.append(i)
print("=== After the replacement")
#TODO
for i in list1:
 print(i.strip())

# 方法二
print("=== Before the replacement")
with open(f_name,"r") as file:
    data = file.read() # .read()只能調用一次
    print(data)
    new_data = data.replace(str_old, str_new)
print("=== After the replacement")
print(new_data)