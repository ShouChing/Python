import pandas as pd
# # big5很重要
# data = pd.read_csv("csvReport.csv",dtype=None,encoding="big5")
# # time = data.時間、speed = data.速度、high = data.高度
# # 欄位名稱逤有特殊符號，如空格、逗號等，會炸掉；要改回括號法
# time = data["時間"]
# speed = data["速度"]
# high = data["高度"]
# print(f"平均速度: {speed.mean():.4f}")
# print(f"平均高度: {high.mean():.4f}")
# print(f"高/速: \n{high/speed}")

# data = pd.read_csv("DeBilt.txt")
# data2 = data[(data[' "Tg"']>data[' "Tg"'].mean()) & (data[' "Tn"']>data[' "Tn"'].mean()) & (data[' "Tx"']>data[' "Tx"'].mean())]
# data3 = data2[' "Tg"']*data2[' "Tn"']*data2[' "Tx"']
# print(f'''tg個數{data2[' "Tg"'].shape[0]}，平均{data[' "Tg"'].mean():.2f}''')
# print(f'''tn個數{data2[' "Tn"'].shape[0]}，平均{data[' "Tn"'].mean():.2f}''')
# print(f'''tx個數{data2[' "Tx"'].shape[0]}，平均{data[' "Tx"'].mean():.2f}''')
# print(data3.max())
# print(data3.min())

data = pd.read_csv("titanic_train.csv")
boysur = data[(data.Survived == 1) & (data.Age>40) & (data.Sex=="male")].shape[0]
boydea = data[(data.Survived == 0) & (data.Age>40) & (data.Sex=="male")].shape[0]
girlsur = data[(data.Survived == 1) & (data.Age>40) & (data.Sex=="female")].shape[0]
girldea = data[(data.Survived == 0) & (data.Age>40) & (data.Sex=="female")].shape[0]
print(f"大於40男生存活: {boysur}人")
print(f"大於40男生死亡: {boydea}人")
print(f"大於40男生存活: {girlsur}人")
print(f"大於40女生死亡: {girldea}人")

# 資料展開
pd.set_option('display.max_rows',None) # 展開資料
print(data)

# 寫入
# data.to_csv("new.csv")