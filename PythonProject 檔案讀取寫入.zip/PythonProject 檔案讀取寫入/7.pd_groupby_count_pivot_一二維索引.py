import pandas as pd
data_t = pd.read_csv("titanic_train.csv")
# .count計算非空值的數量
# 對每個分組中的Name列進行計數：["Name"].count()
print(data_t[data_t.Age>40].groupby(["Sex","Survived"])["PassengerId"].__count(), "\n")

# pivot
print(data_t[data_t.Age>40].pivot_table(index="Sex",columns="Survived",values="Name",
                       aggfunc="count"))
print("-"*50)
# PM2.5.json
data = pd.read_json("PM2.5.json")
data2 = data.groupby("County")
for i,j in data2:
    # print(i) # ('南投縣',...)->元祖
    print(i, j[["SiteName", "Status", "PM2.5"]], "\n")
# 上面[[]]返還dataframe即有兩個索引(row col)
# 下面[]返還series只有一個索引(row)，不會有行標
# for i in data:
#     print(data[i])
#     break

# 疫情
df1 = pd.read_csv("read4.csv", encoding="utf-8", sep=",", header=0)

# 居住縣市病例人數，並按遞減順序顯示
df_county = df1.groupby("居住縣市")["居住縣市"].count()
print(df_county.sort_values(ascending=False))
# 顯示感染病例人數最多的5個國家，並按遞減順序顯示
df_country = df1.groupby("感染國家")["感染國家"].count()
print(df_country.sort_values(ascending=False).head())
# 台北市各區病例人數
df_taipei = df1[df1.居住縣市 == "台北市"]
print(df_taipei.groupby("居住鄉鎮")["居住鄉鎮"].__count())
# 台北市最近病例的日期
print("發病日: " + df_taipei.發病日.max())
