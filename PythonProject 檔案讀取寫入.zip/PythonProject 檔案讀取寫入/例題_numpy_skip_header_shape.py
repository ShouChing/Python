import numpy as np
# 名字多一個逗號總共8值，標題只有7值
# dtype=None，混合型態，會變成一維陣列，無法用行列取值
data = np.genfromtxt("titanic_train.csv",delimiter=",",skip_header=1,dtype=str)
data2 = np.genfromtxt("titanic_train.csv",delimiter=",",skip_header=1)
boysur = data[(data[:,1] == '1') & (data2[:,6]>40) & (data[:,5]=="male")]
boydea = data[(data[:,1] == '0') & (data2[:,6]>40) & (data[:,5]=="male")]
girlsur = data[(data[:,1] == '1') & (data2[:,6]>40) & (data[:,5]=="female")]
girldea = data[(data[:,1] == '0') & (data2[:,6]>40) & (data[:,5]=="female")]
print(f"大於40男生存活: {boysur.shape[0]}人")
print(f"大於40男生死亡: {boydea.shape[0]}人")
print(f"大於40男生存活: {girlsur.shape[0]}人")
print(f"大於40女生死亡: {girldea.shape[0]}人")