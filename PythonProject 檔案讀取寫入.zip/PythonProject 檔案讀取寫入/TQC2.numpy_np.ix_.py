import numpy as np

set_seed = 123
x = np.random.RandomState(set_seed).randint(low=5, high=16, size=15)
print('隨機正整數：', x)

x = x.reshape(3, 5)
print('X矩陣內容：')
print(x)
print('最大：', x.max())
print('最小：', x.min())
print('總和：', x.sum())
print('四個角落元素：')
print(x[np.ix_([0, -1], [0, -1])])
# np.ix_第一個參數為選擇指定的列，這裡只選擇兩個列
# 第二個參數這裡只選擇了兩個行