import pandas as pd
data = pd.read_csv("titanic.csv")
fill = data.Age.mean()-10
data.fillna(fill,inplace=True)
print(f"大於30男生存活: {data[(data.Age>30) & (data.Sex=='male') & (data.Survived==1)].shape[0]}人")
print(f"大於30男生死亡: {data[(data.Age>30) & (data.Sex=='male') & (data.Survived==0)].shape[0]}人")
print(f"大於30男生存活: {data[(data.Age>30) & (data.Sex=='female') & (data.Survived==1)].shape[0]}人")
print(f"大於30女生死亡: {data[(data.Age>30) & (data.Sex=='female') & (data.Survived==0)].shape[0]}人")
for i in range(0,80,10): # 到80歲的8個批次
    print(f"\n{i}歲到{i+10}總人數: {len(data[(data['Age']>=i) & (data['Age']<i+10)])}")
    print(f"男生人間人數: "
          f"{len(data[(data.Age>=i) & (data.Age<i+10) & (data.Sex=='male') & (data.Survived==1)])}")
    print(f"男生天堂人數: "
          f"{len(data[(data.Age>=i) & (data.Age<i+10) & (data.Sex=='male') & (data.Survived==0)])}")
    print(f"女生人間人數: "
          f"{len(data[(data.Age>=i) & (data.Age<i+10) & (data.Sex=='female') & (data.Survived==1)])}")
    print(f"女生天堂人數: "
          f"{len(data[(data.Age>=i) & (data.Age<i+10) & (data.Sex=='female') & (data.Survived==0)])}")