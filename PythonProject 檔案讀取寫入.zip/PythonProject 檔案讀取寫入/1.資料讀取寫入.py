file = open("students.txt","r+")
print("輸入:")
while True:
    data = input()
    if data == "none":
        break
    file.write(data+"\n")
file.close()
# 讀取
file = open("students.txt")
list1 = []
for i in file:
    i = i.strip()
    if i.isalpha and not list1:
        list1.append(i)
        continue
    elif i.isalpha:
        print(" ".join(list1))
        list1 = [i]
        continue
    list1.append(i)
print(" ".join(list1))