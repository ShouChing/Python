import numpy as np
data = np.genfromtxt("csvReport.csv",delimiter=",")
speed = data[1:,1]
height = data[1:,2]
print(speed.mean())
print(height.mean())
print(height/speed)

data = np.genfromtxt("DeBilt.txt",delimiter=",",dtype=None,encoding="UTF-8")
data1 = data[1:,:].astype(float)
tg = data1[:,2]
tg_m = tg.mean()
tn = data1[:,4]
tn_m = tn.mean()
tx = data1[:,6]
tx_m = tx.mean()

# zip、篩選、相乘
# ind = []
# for g,n,x in zip(tg,tn,tx):
#     if g > tg_m and n > tn_m and x > tx_m:
#         ind.append(g*n*x)

# 小括號很重要，"&"優先度大於">"
data2 = data1[(tg > tg_m) & (tn > tn_m) & (tx > tx_m)]
data3 = data2[:,2]*data2[:,4]*data2[:,6]
print(f"tg個數{len(data2)}，平均{tg_m:.2f}")
print(f"tn個數{len(data2)}，平均{tn_m:.2f}")
print(f"tx個數{len(data2)}，平均{tx_m:.2f}")
print(data3.max())
print(data3.min())