f_name = input()
n = int(input())
list1, dict1 = [], {}
# TODO
with open(f_name) as file:
    for i in file:
        list1.extend(i.split())
for i in list1:
    if i in dict1:
        dict1[i] += 1
    else:
        dict1[i] = 1
list3 = [i for i, j in dict1.items() if j == n]
for i in sorted(list3): print(i)