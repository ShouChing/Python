import pandas as pd
import matplotlib.pyplot as plt

# 時間序列，先兩參數，後做排序
data = pd.read_csv("apple.csv",index_col="Date",parse_dates=True)
data2 = pd.read_csv("apple(new).csv",index_col="Date",parse_dates=True)
data = data.sort_index()
data2 = data2.sort_index()
data3 = pd.concat([data,data2]) # concatenate連接
print(data.loc["2012":"2013"].resample('YE')['Close'].mean())
print(data.loc["2014-01":"2014-05",'Close'].mean())
print(data.loc["2014-06":"2014-12",'Close'].mean())
print(data.loc["2015":"2017"].resample('YE')['Close'].mean())
# 季為單位
print(data.resample('QE')['Close'].mean())

# 資料是一列一行，.iloc[0]是取值
# data.loc.resample('YE')['Close'].mean()是Series，所以mean()[0]跟.iloc[0]是一樣的
# 邏輯上要用.iloc[0]
# iloc可以[:,:]，直接切片不行，iloc不包含最後一個但loc包含!!!
ylabel1 = {}
for i in range(2012,2022): # 繪圖
    if i == 2014:
        ylabel1[f"{i}H1"] = data.loc["2014-01":"2014-05"]['Close'].mean()
        ylabel1[f"{i}H2"] = data.loc["2014-06":"2014-12"]['Close'].mean()
    else:
        ylabel1[f"{i}"] = data3.loc[f"{i}",'Close'].mean() # 類似索引片段子
ylabel1 = pd.Series(ylabel1)
# plt.figure(figsize=(14,8))
plt.bar(ylabel1.index,ylabel1,width=0.5,label="Year")
plt.plot(ylabel1.index,ylabel1,color="r",marker="o",label="Year")
plt.xticks(fontsize=7)
plt.legend()
plt.xlabel("Year")
plt.ylabel("Stock Price")
plt.title("Apple")
plt.grid()
plt.show()
pie = data.loc["2016"].resample('ME')['Close'].mean()
season = data.loc["2016"].resample('ME')['Close'].mean().index
plt.pie(pie,labels = season,autopct="%1.1f%%")
plt.show()