import pandas as pd
data = pd.read_json("UV.json")
data.UVI = pd.to_numeric(data.UVI)
n = 5
for i in range(5):
    data2 = data[(data.UVI >= i) & (data.UVI < i + 1)]
    print(f"{data2.SiteName}")
else:
    print(data[data.isnull().any(axis=1)].SiteName)