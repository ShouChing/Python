# 偵測身分證，應用ord轉編碼，重複輸入
while True:
    input1 = input("UID:")
    if (len(input1) == 10 and ord(input1[0])>=65 and ord(input1[0])<=90
        and (input1[1] == "1" or input1[1] == "2")):
        print(f"UID:{input1}")
        break
    else:
        print("Error")
while True:
    input1 = input("Phone number:")
    if len(input1) == 10 and input1[:2] == "09":
        print(f"Phone number:{input1}")
        break
    else:
        print("Error")
while True:
    input1 = input("Email:")
    if "@" in input1 and ".com" in input1:
        print(f"Email:{input1}")
        break
    else:
        print("Error")