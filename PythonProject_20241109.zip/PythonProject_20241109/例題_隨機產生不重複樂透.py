import random
#
# count = 0
# num1 = num2 = num3 = num4 = num5 = num6 = 0
#
# # 亮點:輪次判斷、迴圈禁制產生結果
# while count < 6:
#     temp = random.randint(1,49)
#     if count == 0:  # 以輪次來判斷
#         num1 = temp
#     elif count == 1:
#         while temp == num1:
#             temp = random.randint(1,49)
#         else:
#             num2 = temp
#     elif count == 2:
#         while temp == num1 or temp == num2:
#             temp = random.randint(1,49)
#         else:
#             num3 = temp
#     elif count == 3:
#         while temp == num1 or temp == num2 or temp == num3:
#             temp = random.randint(1,49)
#         else:
#             num4 = temp
#     elif count == 4:
#         while temp == num1 or temp == num2 or temp == num3 or temp == num4:
#             temp = random.randint(1,49)
#         else:
#             num5 = temp
#     elif count == 5:
#         while temp == num1 or temp == num2 or temp == num3 or temp == num4 or temp == num5:
#             temp = random.randint(1,49)
#         else:
#             num6 = temp
#     print(temp)
#     count += 1]

# def value_product(a,b):
#     temp = num1 = num2 = num3 = num4 = num5 = 0
#     while True:
#         # temp一對多判別是否相同
#         # 任何一條件為True就會洗牌
#         if (temp == num1 or temp == num2 or temp == num3 or
#             temp == num4 or temp == num5):
#             temp = random.randint(a, b)
#         else:
#             num6 = num5
#             num5 = num4
#             num4 = num3
#             num3 = num2
#             num2 = num1
#             num1 = temp
#             if num6 != 0:
#                 break
#     print(num1, num2, num3, num4, num5, num6)
# print("請輸入數字範圍:")
# a = eval(input())
# b = eval(input())
# value_product(a,b)

def value_product(n,a,b):
    list = []
    while len(list) < n:
        num = random.randint(a, b)
        if num not in list:
            list.append(num)
    print(list)
print("請輸入隨機範圍:")
a = eval(input())
b = eval(input())
print("請輸入數字個數:")
n = eval(input())
value_product(n,a,b)