# 輸入一個大於10的數字再反轉輸出
num = eval(input("請輸入一個正整數:"))
while num // 10 != 0:
    print(num % 10, end="")
    num = num // 10
else:
    print(num)

# 判斷最小值
temp, num = None, 0
print("請輸入一數字，輸入999代表結束，會判斷所輸入的最小值:")
while num != 999:
    num = eval(input())
    if temp is None or num < temp:
        temp = num
else:
    print(f'所輸入的數值中，最小值 = {temp}')