week, day, temp = 4, 3, []
for i in range(week):
    print(f"Week {i + 1}:")
    for j in range(day):
        temp.append(eval(input(f"Day {j+1}:")))
print(f"Average: {sum(temp)/len(temp):.2f}")
print(f"Highest: {max(temp)}")
print(f"Lowest: {min(temp)}")