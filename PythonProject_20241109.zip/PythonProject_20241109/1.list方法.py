ary = [15, 30, 45, 60, 75]
ary_2 = ['A', 'B', 'C']
ary[-1] = 90  # 形成最後一個元素

ary.append("字")
print(ary)

ary.extend(ary_2)
print(ary)

ary.insert(1, 123.567)
print(ary)

del ary[ary.index(60)]
ary.remove(30)
ary.pop(ary.index(15))
print(ary)

# 如何把全部的 60 移除？
ary_new = [15,30,45,60,75,15,75,60]
while 60 in ary_new:
    ary_new.remove(60)
print(ary_new)