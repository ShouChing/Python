n, list2 = 5, []
for i in range(n):
    for b in range(n-1,i,-1):
        print(" ",end="")
    list1 = [1] * (i + 1)
    for j in range(i+1):
        if i >= 2 and j in range(1,i):
            list1[j] = list2[j-1] + list2[j]
            print(list1[j],end=" ")
            continue
        print(list1[j],end=" ")
    list2 = list1
    print()