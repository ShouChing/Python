string1 = "S中ring"
string2 = "Stttt2"

if "s" in string1:
    print("s in string1")
else:
    print("not in")

string3 = string1 + " " * 3 + string2
print(string3)
print(f"{string1} {string2}")

w = '''
123
456\
456789
'''

n = '000\
+999'
print(type(w))
print(n)

x = 10
y = x
print(id(x))
# 輸出：x 的內存地址
print(id(y))
# 輸出：y 的內存地址，與 x 相同
x = 20
print(id(x))
# 輸出：x 的新內存地址，因為 x 指向了一個新的數字物件
print(id(y))
# 輸出：y 的內存地址保持不變

