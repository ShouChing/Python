# TODO
n = 3
list1 = []
for _ in range(n):
    list2 = []
    for _ in range(n):
        num = eval(input())
        list2.append(num)
    list1.append(list2)
for i in range(n):
    for j in range(n):
        if list1[i][j] == max(map(max, list1)):
            indexm = i, j
        if list1[i][j] == min(map(min, list1)):
            indexn = i, j
print(f'Index of the largest number {max(map(max, list1))} is: {indexm}')
print(f'Index of the smallest number {min(map(min, list1))} is: {indexn}')