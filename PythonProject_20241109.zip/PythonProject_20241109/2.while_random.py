import random

random.seed(5)
print(random.random())

my_list = [1, 2, 3, 4, 5] # 打亂列表
random.shuffle(my_list)
print(my_list)

# number = 0       # 啟動條件
# while number !=5:
#     number=random.randint(0,9)
#     print(number)
#     if number==5:
#         print("I got 5")

# 後撤式迴圈
# while True:
#     number=random.randint(0,9)
#     if number==5:
#         print("I got 5")
#         break
#     else:
#         print(number)

number = random.randint(1, 100)  # 產生1~100之間的亂數
guess = -1                            # 儲存猜測數值
while True:                           # 無窮廻圈
    guess = int(input('請輸入1~100之間的數字，猜一猜！--> '))
    if guess == number:               # if/elif 敘述來反應猜測狀況
        print('你猜對了，數字是：', number)
        break
    elif guess >= number:
       print('數字太大了')
    else:
       print('數字太小了')

# 練習：從 str1 中隨機挑 8 次內容，但有挑選過的就不重覆
str1 = "0012356875"
ans = ""
while len(ans) < 8:
    r = random.choice(str1)
    if r not in ans: ans += r
print(ans)

# 從 3 開始，到 1000 中，所有 3 的倍數之數字和？
# 3 + 6 + 9 ..... + 999 = ?
count, index = 0, 3
while index <= 1000:
    count += index
    index += 3
else:
    print(f"Count={count}, Index={index}")
