# 99乘法表
n = eval(input())
for i in range(1,n+1):
    for j in range(1,n+1):
        count = i * j
        print(f'{j:<2}* {i:<2}= {count:<4}',end="")
    print()

for row in range(1,10):
    for col in range(1,10):
        print("{} * {} = {}",row,col,row*col)
for row in range(1,10):
    for col in range(1,10):
        print(f"{row} * {col} = {row*col}",end="\t")
    print()

print('  |', end = '')
for k in range(1, 10):
    print(f'{k:3d}', end = '')
print("\n",'-' * 32)

for one in range(1, 10):      # 第一層 for/in
    print(one, '|', end = '')
    for two in range(1, 10):   # 第二層 for/in
       print(f'{one * two:3d}', end = '')
    print()

