##eval 溫度
# temp = input('輸入含有符號的溫度 -> ')
# if "°" not in temp:
#     temp = temp[:-1] + "°" + temp[-1]
# if temp[-1] in ['c', 'C']:   # 做溫度轉換
#     fahr = 1.8 * eval(temp[0:-2]) + 32
#     print(f'{temp} = {fahr:%}°F')
#
# weeks = '日一二三四五六'
# number = eval(input('輸入1~7的星期數字-> '))
# if number == 7: number = 0
# print('星期'+weeks[number]+'向您問好！')
print('-' * 32) #換行

#slice
str = "1234567891"
print(str[0:9:1]) #輸出0~8對應1~9
print(str[9:0:-1])
#print(str1[0:9:-1]) #錯誤
print(str.find("5"))
print(str.count("1"))
print(str.replace("1","*",2))
print('-' * 32) #換行

#多行註解、字串
word = '''We all look forward
        to the annual ball because
        it’s great time to dress up.'''
print(word)
print('all 索引:', word.find('all'))  # 尋找all，從W開始，空格算一字元
print('all 索引:', word.find('all', 7))

#split
text = "Hello world this is Python"
words = text.split() #預設以空白格分割，分割後組成一個list
print(words)
print(str.split())   #無空白格所以不分割

# 小練習：中文字串
chinese = "中文字串"
c = " ".join(chinese)
c = c.split(" ")
print(c)

list = "中文字串"
l = [i for i in list]
print(l)


# center填滿
print('split()函式'.center(38, "*"))

#join。若可迭代的元素非字串，則無法使用
i = input("輸入一個句子: ")
# "".join(i)可迭代的是字串裡的每個元素
x = i.split()
a = " ".join(x[-3:])
print(a)
num = ['One', 'Two', 'Three', 'Four'] # 可迭代的是list的每個元素，且元素須為字串
print("".join(num))



