matrix, list1, n = [], [], 3
while True:
    list1.append(eval(input())) # 同時寫
    if len(list1) == n:
        matrix.append(list1)
        list1 = []
    if len(matrix) == n:
        break
maxn = minn = matrix[0][0] # 設的是matrix中的一個值
ind1 = ind2 = 0, 0 # 不先設會炸掉
for i, j in enumerate(matrix):
    if max(j) > maxn:
        maxn = max(j)
        ind1 = (i,j.index(maxn))
    if min(j) < minn:
        minn = min(j)
        ind2 = (i, j.index(minn))
else:
    print(f"Index of the largest number {maxn} is: {ind1}")
    print(f"Index of the smallest number {minn} is: {ind2}")