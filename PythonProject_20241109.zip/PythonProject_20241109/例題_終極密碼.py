import random
down, up, count = 10, 100, 0
start = random.randint(down,up)
while True: # 不計超出範圍的次數
    try:
        input1 = input("請輸入數字:")
        if not input1.isdigit():
            raise TypeError("格式不對，請重新輸入")
        num = eval(input1)
        if num not in range(down, up + 1):
            raise ValueError("超出範圍，請重新輸入")
    except (TypeError, ValueError) as e:
        print(e)
        continue
    else:
        if num > start:
            up = num
            print(f'範圍{down}到{up}')
        elif num < start:
            down = num
            print(f'範圍{down}到{up}')
        else:
            print(f'恭喜猜中，共猜了{count+1}次')
            break
        count += 1
    finally:
        print("輸入完成")