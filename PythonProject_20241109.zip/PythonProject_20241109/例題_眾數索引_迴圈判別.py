list, ans = [], []
count = [0]*10
for i in range(10):
    n = eval(input("輸入:"))
    list.append(n)
    count[list.index(n)] += 1
m =  max(count)
while m in count:
    c = count.index(m)
    ans.append(list[c])
    count[c] = 0
# for i in range(count.count(m)):  #判斷最大count出現幾次
#     if i == 1: i = j
#     c = count.index(m,i)         #第i個最大的數的索引
#     j = c + m
#     ans.append(list[c])
print(f"眾數: {','.join(map(str,ans))}\n出現次數: {m}") #map(fun, iter)

n, i, ans, t = 10, 0, [], 1
x = [int(input("請輸入數字:")) for _ in range(n)]
x.sort()
while n > i:
    c = x.count(x[i])
    if c == t: ans.append((x[i], c))         #兩個以上
    if c > t:
        ans = [(x[i], c)]
        i += c
        t = c
    else: i += c
else:
    if len(ans) > 1:                                 #兩個以上
        ans = [i[0] for i in ans], ans[0][1]
    elif not ans: ans = [(x, 1)]                #眾數為1
    else: ans = ans[0]
    print(f"眾數:{ans[0]}，最多次數:{ans[1]}")

n = eval(input("需產生多少數字?"))
list1 = []
list2 = [0]*n
for i in range(n):
    num = eval(input("請輸入數字:"))
    list1.append(num)
    list2[list1.index(num)] += 1
# 同次數
ans = [list1[i] for i in range(n) if list2[i] == max(list2)]
print(",".join(map(str,ans)))
