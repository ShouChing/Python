tuple2 = (2,4,3)
tuple4 = ('Mary', [78, 92], 'Eric', (65, 91, 101))

tuple4[1].append(123)
print(tuple4)
# tuple1.append(100)錯誤

#Unpacking
t1, t2, t3 = tuple2
print(t1, t2, t3)

x, y, z = 100, 200, 300
print(x, y, z)
x, y, z = z, x, y
print(x, y, z)
