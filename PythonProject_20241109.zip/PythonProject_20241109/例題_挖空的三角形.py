# 挖空的三角形
n = eval(input("請輸入數字:"))
for i in range(n):
    for b in range(n-1,i,-1):
        print(" ",end="")
    for j in range(i+1):
        # 從第三層開始填空、第一個跟最後一個之間填空、最後一層不填空
        if i+1 >= 3 and j in range(1,i) and i != n-1:
            print(" "*2, end="")
            continue
        print("* ",end="")
    print()

# 相同三角形上下相合
for item in range(10):
    print("*" * (item + 1))
for one in range(9,0,-1): #沒有-1不予執行
    print('*'*one)

print("\n",'*' * 32,"\n")