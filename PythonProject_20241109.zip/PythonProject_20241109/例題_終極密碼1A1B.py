import random as rs
n, count, list1 = 4, 0, []
while len(list1) < n:
    num = rs.randint(0,9)
    if num in list1:
        continue
    list1.append(num)
def judge(guess):
    A = B = 0
    for i in range(n):
        if guess[i] == list1[i]:
            A += 1
        elif guess[i] in list1:
            B += 1
    return A,B
while True:
    count += 1
    guess = list(map(int, input("請輸入密碼: ")))
    a, b = judge(guess)
    print(f"{a}A{b}B")
    if a == 4:
        print(f"恭喜猜中，共猜了{count}次")
        break