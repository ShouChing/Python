"""
Python 資料分析應用課程
圖表
"""
import matplotlib.pyplot as plt

def line_chart_1():
    # Sample 1:折線圖
    listx = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    listy = [89, 91, 67, 74, 81, 92, 86, 71, 86, 62, 79, 97]
    # label: 引數是圖例的標題，lw: 線條寬度，ls: 線條種類(style)
    # '-'：實線（默認），'--'：虛線，'-.'：點虛組合，':'：點線
    # marker="s"，square；ms: marker size
    plt.plot(listx, listy, color="blue", lw="1.0", ls="--", label="Math",
             marker="s",ms=10)
    plt.title("Math Score", fontsize=20)     # 圖表標題
    plt.xlabel("Month", fontsize=14)        # x座標標題
    plt.ylabel("Score", fontsize=14)        # y座標標題
    plt.xlim(0, 13)          # x-limit設定x座標範圍，可設置無數據的範圍
    plt.ylim(0, 100)         # 或是裁掉有數據的範圍
    plt.xticks(range(0, 13))      # tick: 勾號、記號、刻度
    plt.yticks(range(0, 110, 10)) # labelsize: 刻度標記(文字)的大小
    plt.tick_params(axis='both', labelsize=10, color='red')
    # grid: 格線，alpha: 透明度
    plt.grid(color='black', linestyle="--", linewidth='1.0', alpha=0.1)
    plt.legend()                  # legend 顯示圖例
    plt.show()

def line_chart_2():
    # Sample 2:多組資料
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))
    fig.suptitle("Test") # fig是整個畫框的設定。super title
    listx1 = [1, 3, 5, 7, 9, 11]
    listy1 = [61, 89, 80, 50, 73, 62]
    # r: red，"-.": 線段種類，s: 正方形(square)
    ax1.plot(listx1, listy1, 'r-.s', label="Math")
    listx2 = [2, 4, 6, 8, 10, 12]
    listy2 = [10, 40, 30, 50, 80, 60]
    ax1.plot(listx2, listy2, 'b--s', label="Chi")
    ax1.set_title("Independent")
    # ax1.set_xticks(range(0, 13, 2))
    ax1.set_xlim(0, 13)
    ax1.legend()
    # 同一組人，不同科目成績；也就是x座標相同，y座標不相同
    ax2.plot(listx1, listy1, 'r-.s', listx1, listy2, 'b--s',ms=10)
    ax2.set_title("依賴")
    # ax2.set_xticks(range(0, 13,2))
    ax2.set_xlim(0, 13)
    plt.rcParams["font.sans-serif"] = ["Microsoft JhengHei"]
    plt.show()

def line_chart_3():
    # Sample 3:長條圖
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))
    plt.rcParams["font.sans-serif"] = ["Microsoft JhengHei"]
    listx = ['c', 'c++', 'c#', 'java', 'python']
    listy = [45, 28, 38, 32, 50]
    ax1.bar(listx, listy, width=0.5, color='r')
    ax2.barh(listx, listy, height=0.5, color='g') # 橫條圖
    ax1.set_title("資訊程式課程選修人數")
    ax1.set_xlabel("程式課程")
    ax1.set_ylabel("選修人數")
    plt.show()

def line_chart_4():
    # Sample 4:堆疊長條圖
    plt.rcParams["font.sans-serif"] = "Microsoft JhengHei"
    listx = ['c', 'c++', 'c#', 'java', 'python']
    listy1 = [25, 20, 20, 16, 28]
    listy2 = [20, 8, 18, 16, 22]
    plt.bar(listx, listy1, width=0.5, bottom=listy2, label='男')
    plt.bar(listx, listy2, width=0.5, label='女')
    plt.title("資訊程式課程選修人數")
    plt.xlabel("程式課程")
    plt.ylabel("選修人數")
    plt.legend()
    plt.show()

def line_chart_5():
    # Sample 5:並列長條圖
    plt.rcParams["font.sans-serif"] = "Microsoft JhengHei"
    width = 0.25
    listx = ['c', 'c++', 'c#', 'java', 'python']
    listx1 = [x - width / 2 for x in range(len(listx))]
    listx2 = [x + width / 2 for x in range(len(listx))]
    listy1 = [25, 20, 20, 16, 28]
    listy2 = [20, 8, 18, 16, 22]
    plt.bar(listx1, listy1, width, label='男')
    plt.bar(listx2, listy2, width, label='女')
    plt.xticks(range(len(listx)), labels=listx) # 前面劃定刻度，後面貼上標籤
    plt.legend()
    plt.title("資訊程式課程選修人數")
    plt.xlabel("程式課程")
    plt.ylabel("選修人數")
    plt.show()

def scatter_chart():
    # Sample 1:散佈圖
    listx = [31, 15, 20, 25, 12, 18, 45, 21, 33, 5, 18, 22, 37, 42, 10]
    listy = [68, 20, 61, 32, 45, 56, 10, 18, 70, 64, 43, 66, 19, 77, 21]
    scale = [x ** 4 for x in [5, 4, 2, 6, 7, 1, 8, 9, 2, 3, 2, 4, 5, 7, 2]]
    plt.xlim(0, 50)
    plt.ylim(0, 80)
    # marker是圖案，s是大小
    plt.scatter(listx, listy, c='r', s=scale, marker='o', alpha=0.5)
    plt.show()

def pie_chart():
    # Sample 1:圓餅圖
    plt.rcParams["font.sans-serif"] = "Microsoft JhengHei"
    sizes = [25, 30, 15, 10]
    labels = ["北部", "西部", "南部", "東部"]
    colors = ["red", "green", "blue", "yellow"]
    explode = (0.3, 0, 0.2, 0)
    plt.pie(sizes,
            explode=explode,   # 突出，將扇形從餅圖中心偏移出去
            labels=labels,
            colors=colors,
            labeldistance=1.2, # 標籤與餅圖的距離
            autopct="%.1f%%",  # automatic percentage
            pctdistance=0.6,
            shadow=True,
            startangle=90)     # 餅圖繪製是逆時針的
    # 長寬比為1:1，兩座標軸的比例，非必要
    plt.axis('equal')
    plt.show()

def multi_fig_1():
    # Sample 1:同時呈現多組圖表，設定圖表區
    # 新增圖表區1
    plt.figure()
    plt.plot([1, 5, 25])
    # 新增圖表區2並設定屬性
    # linewidth是figure的寬；dpi是解析度；frameon是否顯示邊框，預設開啟
    plt.figure(figsize=[8, 4], dpi=84, facecolor="whitesmoke", edgecolor="r",
               linewidth=5)
    plt.plot([4, 7, 12])
    plt.show()

def multi_fig_2():
    # Sample 2:圖表區中，加入多張圖表 2列1欄
    plt.figure(figsize=[8, 8],edgecolor="r", linewidth=5) # 調整畫布，影像儲存後圖的大小
    plt.subplot(211)
    plt.title(label='Chart 1')
    plt.plot([1, 6, 18], 'r:o')
    plt.subplot(212)
    plt.title(label='Chart 2')
    plt.plot([1, 5, 25], 'g--o')
    # 自動調整子圖之間的間距
    plt.tight_layout()
    plt.show()

def multi_fig_3():
    # Sample 3:圖表區中，加入多張圖表 相對位置
    plt.figure(figsize=[8, 8])
    # axes: 從左下開始對齊；左、下、寬、高
    plt.axes([0.1, 0.1, 0.5, 0.5]) # 0,0,0.5,0.5，會貼其左下，座標軸消失
    plt.title(label='Chart 1')
    plt.plot([1, 2, 3], 'r:o')
    plt.axes([0.5, 0.2, 0.8, 0.3])
    plt.title(label='Chart 2')
    plt.plot([1, 2, 3], 'g--o')
    plt.show()

if __name__ == '__main__':
    # line_chart_1()
    # line_chart_5()
    # scatter_chart()
    multi_fig_3()
