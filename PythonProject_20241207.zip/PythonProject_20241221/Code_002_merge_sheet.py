# -*- coding: utf-8 -*-
from pathlib import Path
import pandas as pd

folder_path = Path('./Code_002')

files = folder_path.glob('*一年九班*.xlsx')
# open不能處理excel
with pd.ExcelWriter('./Code_002/合併活頁簿.xlsx') as wb:
    for i in files:
        stem_name = i.stem
        data = pd.read_excel(i, sheet_name=0)
        data.to_excel(wb, sheet_name=stem_name, index=False)
