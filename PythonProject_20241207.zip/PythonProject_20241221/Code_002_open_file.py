# -*- coding: utf-8 -*-
import xlwings as xw

app = xw.App(visible=True, add_book=False)
location = './Code_002/書籍清單.xlsx'
app.books.open(location)

