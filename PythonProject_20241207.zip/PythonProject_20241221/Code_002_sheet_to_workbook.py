# -*- coding: utf-8 -*-
import xlwings as xw

app = xw.App(visible=False, add_book=False)

location = './Code_002/成績單.xlsx'
wb = app.books.open(location)
ws = wb.sheets

for i in ws:
    new_wb = app.books.add()
    new_ws = new_wb.sheets[0]
    i.copy(before=new_ws)
    new_wb.save(f'./Code_002/{i.name}.xlsx')
    new_wb.close()

app.quit()
