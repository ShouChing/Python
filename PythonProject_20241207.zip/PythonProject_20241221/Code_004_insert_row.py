# -*- coding: utf-8 -*-
from openpyxl import load_workbook

wb = load_workbook('./Code_004/外包錄音費.xlsx')
ws = wb['Sheet1']
ws.insert_rows(4, 1)
wb.save('./Code_004/外包錄音費1.xlsx')
