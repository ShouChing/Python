# -*- coding: utf-8 -*-
from pathlib import Path

old = Path('./Code_002/書籍清單.xlsx')
new = Path('./Code_001/書籍資訊.xlsx')

old.rename(new)
