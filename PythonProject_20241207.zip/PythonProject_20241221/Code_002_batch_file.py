# -*- coding: utf-8 -*-
import xlwings as xw

app = xw.App(visible=False, add_book=False)

num=3
for i in range(num):
    wb = app.books.add()
    wb.save(f'./Code_002/成績單_{i+1}.xlsx')
    wb.close()
app.quit() # 關閉excel程序

