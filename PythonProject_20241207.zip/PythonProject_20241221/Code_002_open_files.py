# -*- coding: utf-8 -*-
import xlwings as xw
from pathlib import Path

app = xw.App(visible=True, add_book=False)

location = Path('Code_002')
files= location.glob('*.xls*')
print(files)

for i in files:
    app.books.open(i)
