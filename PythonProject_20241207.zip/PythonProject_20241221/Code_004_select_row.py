# -*- coding: utf-8 -*-
import pandas as pd
df=pd.read_excel("./Code_004/trip.xlsx")
pd.set_option('display.unicode.ambiguous_as_wide', True)
pd.set_option('display.unicode.east_asian_width', True)
pd.set_option('display.width', 180) # 設置寬度

print(df) #原始資料庫
print()
print(df.loc[0]) # 提取標籤，
print()
print(df.loc[[0,3,5]]) #多數列以串列表示
print()
print(df.iloc[0:5]) #選取連續多列
print(df[df["員工編號"]=="A0001"]) #根據設定條件來篩選
# dataframe是一列列上至下排列，鎖定df["員工編號"]=="A0001"此列
print(df["員工編號"]=="A0001")
