# -*- coding: utf-8 -*-
from pathlib import Path
import xlwings as xw

app = xw.App(visible=False, add_book=False)
location = Path(r'./Code_002/')
files = location.glob('*.xlsx')

for i in files:
    name = r'./' + str(i.with_suffix('.xls'))
    print(name)
    wb = app.books.open(i)
    wb.api.SaveAs(name, FileFormat=56)
    wb.close()

app.quit()
