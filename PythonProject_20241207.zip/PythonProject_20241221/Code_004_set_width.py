# -*- coding: utf-8 -*-
import xlwings as xw

app = xw.App(visible=False, add_book=False)
wb= app.books.open('./Code_004/教育訓練.xlsx')
ws = wb.sheets['Sheet1']

ws.autofit()
wb.save('./Code_004/教育訓練ok.xlsx')

wb.close()
app.quit()
