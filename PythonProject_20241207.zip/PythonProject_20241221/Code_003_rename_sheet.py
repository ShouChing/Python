# -*- coding: utf-8 -*-
import xlwings as xw

app = xw.App(visible=False, add_book=False)
wb = app.books.open('./Code_003/更名工作表.xlsx')
ws = wb.sheets

for i in ws:
    if i.name == '第一小隊':
        i.name = '第一組'
        break

wb.save('./Code_003/更名工作表ok.xlsx')
wb.close()
app.quit()
