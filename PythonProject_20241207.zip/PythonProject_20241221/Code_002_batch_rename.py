# -*- coding: utf-8 -*-
from pathlib import Path

location = Path('./Code_002')
file_list = location.glob('*成績單*.xlsx')

for i in file_list:
    old = i.name
    new_name = old.replace('一年八班成績', '一年九班成績')
    # .with_name繼承原有路徑生成新路徑
    new_path = i.with_name(new_name)
    i.rename(new_path)
