# -*- coding: utf-8 -*-
from openpyxl import load_workbook

wb = load_workbook('./Code_004/cell_test.xlsx')

sheet = wb['書單1']

# 根據位置取得儲存格
c = sheet['A4']
# 取得儲存格資料
print(c.value)

# 修改資料
c.value = "App Inventor"
print(c.value)

# 以行號、列號取得儲存格資料
c = sheet.cell(row=4, column=4)
print(c.value)

# 取得指定範圍內儲存格物件
cellRange = sheet['A2':'A8']

print("-"*20)
# 以 for 迴圈逐一處理每個儲存格
# row是一個tuple
for row in cellRange:
    print(row[0].value)

#將修改過的活頁簿內容以另一個檔名儲存
wb.save('./Code_004/cell_test1.xlsx')
