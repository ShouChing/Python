# -*- coding: utf-8 -*-
from pathlib import Path

location = Path('Code_002/單字表.xlsx123')

print(location)

print("主檔名:" + location.stem)
print("副檔名:" + location.suffix)
print("檔案全名:" + location.name)
