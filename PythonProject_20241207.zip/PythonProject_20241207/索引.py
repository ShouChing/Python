import pandas as pd

# 創建數據框，列標籤為整數
df = pd.DataFrame({
    0: [1, 2, 3, 4, 5],
    1: [6, 7, 8, 9, 10],
    2: [11, 12, 13, 14, 15]
})

# 選擇標籤為 1 的列
print(df[1])
print(df[0:2])
print(df.loc[0:2])
print(df.loc[:,0:2])
print(df.iloc[:,0:2])