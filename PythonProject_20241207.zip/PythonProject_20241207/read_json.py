# -*- coding: utf-8 -*-
"""
處理 Json 資料
{
  "name": "Jason",
  "age": 21,
  "skill": ["Python", "C/C++"],
  "married": false
}
"""
import json

# 開啟 JSON 檔案
# f = open("data.json")
with open("data.json") as f:
    # 讀取 JSON 檔案
    p = json.load(f)

    # 查看整個 JSON 資料解析後的結果
    print("p =", p)
    print(type(p))

    # 取得 name 的值
    print("name =", p["name"])

    # 取得 age 的值
    print("age =", p["age"])

    # 取得 skill 的值
    print("skill =", p["skill"])

    # 取得 married 的值
    print("married =", p["married"])

    # 取得陣列中的內容
    print(type(p["skill"]))
    print(len(p["skill"]))

    # 一維陣列的取值方式
    print(p["skill"][0])

