# -*- coding: utf-8 -*-
"""
Python 資料分析應用課程 - C002
處理 CSV、Excel 資料
"""
import pandas as pd

# 第一段，用 pandas 讀取 excel 或 csv 檔
# df = pd.read_excel('208-3.xls', sheet_name=['102', '108'])
# print(df)

# 第三段，用 pandas 讀取 excel 欄資料
# 資料檔案要先整理，表頭會影響到欄的讀取
# df = pd.read_excel('208-3.xls', sheet_name='108_2')
# print(df[['縣市別', '男性參賽選手數']]) # [[]]dataframe有col索引標籤
# df = pd.read_excel('208-3.xls', sheet_name='108_2', usecols='A, C:D')
# print(df)

# df[0]單一取值被視為行，df[1:3]索引片段被視為列
# 第四段，用 pandas 讀取 excel 列資料
# 在讀取時，限制讀取列數 => nrows-1
# df = pd.read_excel('208-3.xls', sheet_name='108_2', nrows=10)
# print(df)
# 全部讀取後，再選出範圍
# df2 = pd.read_excel('208-3.xls', sheet_name='108_2')
# 要注意的是，是 0-9 列!!
# new_df_1 = df2[0:10]
# print(new_df_1)
# new_df_2 = df[5:15]
# print(new_df_2)

# 第五段，用 pandas 讀取 excel 儲存格資料
df = pd.read_excel('208-3.xls', sheet_name='108_2')
# Dataframe.at[position, label]
# 此例為讀取'縣市別' 中的第二個(0是第1個)之值
d2 = df.at[6, '總計']
print(d2)
print(df.loc[6,'總計'])