# -*- coding: utf-8 -*-
"""
Line 貼圖抓取與儲存
"""
import requests, os, json
from bs4 import BeautifulSoup

url = 'https://store.line.me/stickershop/product/28990628/zh-Hant'
html = requests.get(url)

# print(type(html.text))

soup = BeautifulSoup(html.text, 'html.parser')

# print(type(soup))

# 建立目錄儲存圖片
images_dir = "line_image/"
if not os.path.exists(images_dir):
    os.mkdir(images_dir)

# 下載貼圖
datas = soup.find_all('li', {'class': 'mdCMN09Li FnStickerPreviewItem animation-sticker'})
print(type(datas))
print(datas)

for data in datas:
    # print(data.get('data-preview'))
    # print('------------------------')

    # 將字串資料轉換為字典
    imginfo = json.loads(data.get('data-preview'))

    print(imginfo)
    print('------------------------')

    id = imginfo['id']
    s_url = imginfo['staticUrl']

    # print(s_url)

    imgfile = requests.get(imginfo['staticUrl'])  # 載入圖片

    full_path = os.path.join(images_dir, id)  # 儲存的路徑和主檔名
    # 儲存圖片
    with open(full_path + '.png', 'wb') as f:
        f.write(imgfile.content)
        print(full_path + '.png')  # 顯示儲存的路徑和檔名"
