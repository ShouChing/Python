import requests

# # 使用 GET 方式下載普通網頁
# response = requests.get('https://www.lccnet.com.tw/lccnet')
# # print(type(response))
# # print(response)
#
# # 伺服器回應的狀態碼
# print(response.status_code)
#
# # 檢查狀態碼是否 OK
# if response.status_code == requests.codes.ok:
#    print("OK")
#
# print(response.text)

# 增加 URL 查詢參數
# 查詢參數
my_params = {'key1': 'value1', 'key2': 'value2'}

# response = requests.get('http://httpbin.org/get')
# print(response.text)
#
# response = requests.post('http://httpbin.org/post')
# print(response.text)

# 將查詢參數加入 GET 請求中
response = requests.get('http://httpbin.org/get', params = my_params)

# 觀察 URL
print(response.url)
print(response.text)



