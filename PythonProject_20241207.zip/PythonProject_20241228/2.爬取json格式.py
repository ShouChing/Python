import json
import requests

# 官網查詢
url = 'https://trends.google.com/trends/api/dailytrends'
my_headers = {'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'}
payload = {"hl": "zh-TW",
            "tz": "-480", # 第8時區*60
            # "ed": "20200401",
            "geo": "TW",
            "ns": "15",}
html = requests.get(url, params = payload)
html.encoding = 'utf-8'
_, datas = html.text.split(',',1)
jsondata = json.loads(datas) # 將json格式的字串轉為字典
# 爬json格式並讀取，json印出一行
trend=jsondata['default']['trendingSearchesDays']
for trend in trend:
    formattedDate=trend['formattedDate']
    print('日期:' + formattedDate)
    print()
    for data in trend['trendingSearches']:
        print('【主題關鍵字:' + data['title']['query'] + '】')
        print()
        for content in data['articles']:
            print('標題:', content['title'])
            print('媒體:', content['source'])
            print('發佈時間:', content['timeAgo'])
            print('內容:', content['snippet'])
            print('相關連結:', content['url'])
            print()
        print('-'*50)