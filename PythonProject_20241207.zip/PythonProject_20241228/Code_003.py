import datetime
import json
import re
import requests

def fetch_trend(fetch_date):
    url = 'https://trends.google.com.tw/trends/api/dailytrends?hl=zh-TW&tz=-480&ed=' + fetch_date + '&geo=TW&ns=15'
    print(url)

    resp = requests.get(url)

    data = re.sub(r'\)\]\}\',\n', '', resp.text)
    trend_tree = json.loads(data)

    if len(trend_tree['default']['trendingSearchesDays']) == 0:
        print('Empty trend data at ' + fetch_date)
        return

    keywords = trend_tree['default']['trendingSearchesDays'][0]['trendingSearches']

    for i in keywords:
        title = i['title']['query']
        formattedTraffic = i['formattedTraffic']

        imageUrl = 'none'
        if 'imageUrl' in i['image']:
            imageUrl = i['image']['imageUrl']
        articles = i['articles']
        shareUrl = i['shareUrl']
        fetch_date = int(fetch_date)

        # 相關的搜尋，只取出關鍵字
        relatedQueries = []
        for r in i['relatedQueries']:
            relatedQueries.append(r['query'])

        if len(relatedQueries) > 0:
            print(relatedQueries)

# 最多30天前
days = 3

# 取得今天當結束日期
day_end = datetime.datetime.today()

for d in range(days, 0, -1):
    day_start = day_end - datetime.timedelta(days=d)
    format_day = datetime.datetime.strftime(day_start,'%Y%m%d')
    print(d, format_day)

    fetch_trend(format_day)