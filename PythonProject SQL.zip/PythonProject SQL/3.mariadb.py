import mariadb
con = mariadb.connect(host='127.0.0.1',port=3306,
                      user='root',password='0000',
                      database='test')
cursor = con.cursor()
cursor.execute("INSERT INTO addressbook (name, mobilephone, email) VALUES ('Los', '0900888888', 'Jan@gmail.com')")
con.commit() # 寫入
cursor.execute('select * from addressbook')
for i in cursor:
    print(i[1])
con.close()