CREATE TABLE IF NOT EXISTS `addressbook` (
	`name`	TEXT,
	`mobilephone`	TEXT,
	`email`	TEXT
);
INSERT INTO `addressbook` VALUES ('123','123','123');
INSERT INTO `addressbook` VALUES ('123','123','123');
INSERT INTO `addressbook` VALUES ('456','456','456');
INSERT INTO `addressbook` VALUES ('123','123','123');
