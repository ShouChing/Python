import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
con = sqlite3.connect('./dataBase/Northwind.db')
dataframes = []
for i in range(3): # 這邊已經聚合一次了
    data = con.execute(f"""
    SELECT 
        COUNT(o.OrderDate), 
        e.FirstName, 
        e.LastName
    FROM Orders o INNER JOIN Employees e
    ON o.EmployeeID = e.EmployeeID
    WHERE o.OrderDate LIKE '%{1996+i}%' 
    GROUP BY e.FirstName ORDER BY o.OrderDate ASC;
    """)
    dataf = pd.DataFrame(data, columns=['OrderCount', 'FirstName', 'LastName'])
    dataf['Year'] = 1996 + i  # 加入年份
    dataframes.append(dataf)
all_data = pd.concat(dataframes, ignore_index=True)

# bar
data1997 = all_data[all_data.Year==1997]
plt.bar(data1997['FirstName'],data1997['OrderCount'],width=0.5,label="OrderCount")
plt.legend()
plt.xticks(data1997['FirstName'], fontsize=8)
plt.xlabel("FirstName")
plt.ylabel("OrderCount")
plt.title("1997 - North - Orders by Employee")
plt.grid()
plt.show()
# pie
plt.pie(data1997['OrderCount'], labels=data1997['FirstName'], autopct="%1.1f%%")
plt.title("1997 - North - Orders by Employee")
plt.show()
# plot
for i in all_data['FirstName'].unique():
    data_e = all_data[all_data['FirstName'] == i]
    plt.plot(data_e['Year'], data_e['OrderCount'], marker='o', label=i)
plt.xticks(all_data['Year'], fontsize=8)
plt.legend()
plt.xlabel("Year")
plt.ylabel("OrderCount")
plt.title("North - Orders by Employee")
plt.grid()
plt.show()