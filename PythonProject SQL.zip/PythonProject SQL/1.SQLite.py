import sqlite3
con = sqlite3.connect('./dataBase/address.db')
data = con.execute('select * from addressbook')
for i in data:
    print(i[1])
con.close()