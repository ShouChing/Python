import random as rd
# 隨機添加
dict1 = {}
list1 = ["ABC", "DEF", "EDR", "EDG", "SER", "EDR", "QWS", "DRR"]
for i in range(1, 6):
    dict1[i] = rd.choice(list1)
print(dict1)

# enumerate遍歷 輸出index跟item
dict2 = {index: item for index, item in enumerate(list1)}
print(dict2)

print()
# 分類添加
stu = [i for i in range(1,11)]
ans = {"15號之前": [], "15號之後": []}
for s in stu:
    if s % 2 != 0:
        ans["15號之前"].append(s)
    else:
        ans["15號之後"].append(s)
print("值日生分配情況:")
for i, j in ans.items():
    print(f'{i}: {", ".join(map(str, j))}')

print()
#dict 添加
score = {'Tom':95, 'Stever':78, 'John':47, 'Eward':67,
          'Cathy':64, 'Eric':52, 'Ivy':72, 'Grac':82,
         'Kevin':93, 'Nacy':35, 'Laura':75, 'David':88}
data = {} #空字典
for key, value in score.items():
    tmp = value // 10 #取整數商數
    if tmp not in data: data[tmp] = [] # 重要
    data[tmp].append(key)
for k, v in data.items():
    print(f'{k}: {", ".join(v)}')
