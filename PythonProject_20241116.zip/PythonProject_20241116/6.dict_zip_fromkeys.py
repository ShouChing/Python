my_dict = dict(key1 = 0, key2 = 5)
print(my_dict)
# 使用包含一個二元組的"序列"來創建字典，例如列表或元組
# tuple: 使用()創建，如果只有單一元素，需要(element,)
my_dict2 = dict((('key2', 'value2'),))
my_dict3 = dict([('key3', 'value3')])
# my_dict4 = dict(['key1', 'value1'])錯誤
print(my_dict2)
print(my_dict3)

print()
# zip() 用dict、list、tuple、format讀取，zip各挑一個配對
list1 = ['Sunday', 'Monday', 'Tuesday']
list2 = ['週日', '週一', '週二']
dict3 = dict(zip(list1, list2))
# dict4 = list(zip(list1, list2))
# dict5 = tuple(zip(list1, list2))
dict6 = {}
for i, j in zip(list1, list2): dict6[i] = j
print("dict:",dict3)
# print("list:",dict4)
# print("tuple:",dict5)
# print("format:",dict6)

print()
# fromkeys 用法，把可迭代物拆開成key
dict5 = {}.fromkeys('ABC', 123)
print(dict5)

list3 = ["ABC", "CDE", "EDR", "HGT", "QAH", "DET"]
dict6 = {}.fromkeys(list3, 12345)
print(dict6)


