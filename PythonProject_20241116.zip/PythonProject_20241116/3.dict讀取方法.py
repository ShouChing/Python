dict2 = {'John':35, 'Eric':61, 'Marry':41, 'Hank':53}

# 讀取方法: get, dict方法, list、tuple搭配dict方法, for
# get 方法，預設None不添加
print(dict2.get("John1"))
print(dict2.get("John"))
# setdefault，預設None會添加
print(dict2.setdefault("John1", 100))
print(dict2)
print(dict2.setdefault("John"))

print("\ndict方法:")
# dict
print(dict2.keys(), type(dict2.keys()))
print(dict2.values(), type(dict2.values()))
print(dict2.items(), type(dict2.items()))

print("\nlist、tuple方法:")
# list、tuple
print(dict2)
print(list(dict2))  # key
print(tuple(dict2)) # key
print(list(dict2.values()))
print(tuple(dict2.values()))

print("\nformat方法:")
# for
for i in dict2:
    print(f'{i:s} {dict2[i]:10d}')
for i, j in dict2.items(): # items()化為元組
    print(f'{j:d} {i:s}')
for i in dict2.items():    # items()化為元組
    print(i)