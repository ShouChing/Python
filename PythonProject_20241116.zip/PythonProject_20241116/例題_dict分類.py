# score = {'Tom':95, 'Stever':78, 'John':47, 'Eward':67,
#           'Cathy':64, 'Eric':52, 'Ivy':72, 'Grac':82,
#          'Kevin':93, 'Nacy':35, 'Laura':75, 'David':88}
# data = {} #空字典
# for key, value in score.items():
#     tmp = value // 10 #取整數商數
#     if tmp not in data: data[tmp] = []
#     data[tmp].append(key)
# for key in data.items(): print(key)
#
#

