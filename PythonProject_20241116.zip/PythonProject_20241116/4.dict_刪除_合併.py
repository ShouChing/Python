dict2 = {'John':35, 'Eric':61, 'Marry':41, 'Hank':53, 'Wang':None}
dict3 = {1:"John", 2:'Eric', 3:'Marry', 4:'Hank'}
dict4 = {3:"John", 4:'Eric', 5:'Marry', 6:'Hank'}

# Dict 的 刪除
popvalue = dict2.pop("Wang", None) #被刪除元素以儲存
# dict2.popitem()
# del dict2['John']
print(dict2, "\npop: %s" % popvalue)

print()
# Dict 的 合併
dict2.update(dict3)
print(dict2)
print(dict2 | dict3)
# 有相同 key 時，後項取代前項
print("合併前: ", dict4) # dict3 = {1:"John", 2:'Eric', 3:'Marry', 4:'Hank'}
dict4.update(dict3)
print("合併後: ", dict4)