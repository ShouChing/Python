num1 = {23, 24, 26}                     # 準備集合1
num2 = {23, 24, 33, 45}                 # 準備集合2

print(num1 | num2)                      # 運算子| 聯集計算
print(num1.union(num2))                 # num1 | num2
print(num1.union('One', ('Two', 25)))

print()
print(num1 & num2)                      # 運算子& 交集計算

print()
print(num1 - num2)
print(num2 - num1)
print(num1.difference(num2))            # 輸出{26}
print(num2.difference(num1))            # 輸出{45, 33}

print()
# 對等差集計算，運算是(num1 - num2) | (num2 - num1)
print('num1 ^ num2 = ', num1 ^ num2)
result = num1.symmetric_difference(num2)     # 輸出{33, 26, 45}
print('對等差集運算', result)

print()
# num1 |= num2
# num1 &= num2
# num1 -= num2
num1 ^= num2
print(num1)
print(num2)


