# Set
set1 = {None}
set2 = {1, 2, 3, 4, 5}
set21 = {5, 1, 3, 2, 4, 1, 3, 2, 4, 5}
set3 = {1, 2, 3, 'abc', 'def', 10.8, True, False}

# hash 身分證碼
print(hash("abc"))
print("abc".__hash__())

print(set21)
if set2 == set21:
    print("Set 相同")

str1 = "CDRG"
str2 = "DQVT"

set5 = set(str1)
set6 = set(str2)
set7 = set5 & set6
print(set7)
