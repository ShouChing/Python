# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 13:24:32 2021

@author: Alvin
"""

from flask import Flask
from flask import render_template
app = Flask(__name__)

@app.route("/")
def hello():
    return "Hello Flask!"

@app.route("/css")
def css():
    return render_template(r"css.html")

if __name__ == "__main__":
    app.run()
    


