from flask import Flask
from flask_uploads import UploadSet, IMAGES, configure_uploads
from flask import request

# from werkzeug.utils import secure_filename
# from werkzeug.datastructures import  FileStorage

app = Flask(__name__)

app.config['SECRET_KEY'] = 'development'
app.config['UPLOADED_DEF_DEST'] = r'./static/image'
app.config['UPLOADED_DEF_URL'] = '\\static\\image\\'

abc = UploadSet(name='def', extensions=IMAGES)
configure_uploads(app, abc)

html = '''
<!DOCTYPE html>
<html lang="en">
<h1>測試上傳</h1>
<form method=post enctype=multipart/form-data>
<input type=file name=in_abc>
<input type=submit value=Upload>
</form>
</html>
'''


@app.route('/uploads/', methods=['GET', 'POST'])
def uploads():
    if request.method == 'POST' and 'in_abc' in request.files:
        filename = abc.save(request.files['in_abc'])
        print(filename)
        file_url = abc.url(filename)
        print(file_url)
        return file_url
    return html


if __name__ == '__main__':
    app.run(debug=True)
    
    