# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 13:24:32 2021

@author: Alvin
"""
import random as rs
from flask import Flask, request, redirect, render_template, session, url_for
from flask_mail import Mail, Message
app = Flask(__name__)
app.secret_key = 'Jack secret key'

@app.route("/email")
def email():
    app.config['MAIL_SERVER'] = 'smtp.gmail.com'
    app.config['MAIL_PORT'] = 465
    app.config['MAIL_USERNAME'] = session['email']
    app.config['MAIL_PASSWORD'] = 'tlycjaypjsmwiyer'
    app.config['MAIL_USE_TLS'] = False
    app.config['MAIL_USE_SSL'] = True
    mail = Mail(app)
    session['everify'] = ''.join(rs.choices('0123456789', k=4))
    msg = Message('Verification', sender = session['email'], recipients = [session['email']])
    msg.html = f"<br><a href = '{request.url_root}verify?everify={session['everify']}'><b>點擊驗證郵箱</b></a>"
    mail.send(msg)
    return "請通過郵箱點擊驗證"

@app.route('/verify', methods=['POST', 'GET'])
def verify():
    # 從網址接收參數everify
    everify = request.args.get("everify")
    if everify == session['everify']:
        session['everify'] = "Right"
        return redirect(url_for('index'))
    else:
        return "<br><a href = '/email'><b>點擊重新驗證郵箱</b></a>"

@app.route('/')
def index():
    if session.get('everify') == "Right":
        pass
    elif session.get('everify') == "OK":
        session.pop('everify', None)
    else:
        return "您暫未登入， <br><a href = '/login'>" + \
        "<b>點選這裡登入</b></a>" + "<br><a href = '/regist'><b>點選這裡註冊</b></a>"
    return '登入使用者名稱是:' + session['username'] + '<br>' + \
                 "<b><a href = '/logout'>點選這裡登出</a></b>"

@app.route('/login',methods = ['POST', 'GET'])
def login():
    if request.method == 'POST':
        if session.get("passname") is None:
            return "查無帳密，<br><a href = '/regist'><b>點選進行註冊</b></a>"
        if request.form['user'] == session['username'] and request.form['pass'] == session['passname']:
            session['everify'] = "OK"
            return "尚未驗證郵箱，是否驗證<br><a href = '/email'>" + \
        "<b>是，點擊驗證郵箱</b></a>" + "<br><a href = '/login'><b>否，不驗證郵箱</b></a>"
        else:
            return "登入錯誤，<br><a href = '/login'><b>重新登入</b></a>"
    else:
        return render_template('index.html')

@app.route('/regist',methods = ['POST', 'GET'])
def regist():
    if request.method == 'POST':
        session['username'] = request.form['user']
        session['passname'] = request.form['pass']
        session['email'] = request.form['email']
        return "<b>註冊成功</b>" + "<br><a href = '/email'><b>點擊驗證郵箱</b></a>"
    else:
        return render_template('index2.html')

@app.route('/logout')
def logout():
   # remove the username from the session if it is there
   session.pop('username', None)
   session.pop('passname', None)
   session.pop('everify', None)
   return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True) # http://127.0.0.1:5000