# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 13:24:32 2021

@author: Alvin
"""
import random as rs
import mariadb
from flask import Flask, request, redirect, render_template, session, url_for
from flask_mail import Mail, Message
app = Flask(__name__)
app.secret_key = 'Jack secret key'

def db_connect(database="regist"):
    return mariadb.connect(host='127.0.0.1', port=3306,
                          user='root', password='0000',
                          database=database)

@app.route("/email")
def email():
    app.config['MAIL_SERVER'] = 'smtp.gmail.com'
    app.config['MAIL_PORT'] = 465
    app.config['MAIL_USERNAME'] = session['email']
    app.config['MAIL_PASSWORD'] = 'tlycjaypjsmwiyer'
    app.config['MAIL_USE_TLS'] = False
    app.config['MAIL_USE_SSL'] = True
    mail = Mail(app)
    session['everify'] = ''.join(rs.choices('0123456789', k=4))
    msg = Message('Verification', sender = session['email'], recipients = [session['email']])
    msg.html = f"<br><a href = '{request.url_root}verify?everify={session['everify']}'><b>點擊驗證郵箱</b></a>"
    mail.send(msg)
    return "請通過郵箱點擊驗證"

@app.route('/verify', methods=['POST', 'GET'])
def verify():
    # 從網址接收參數everify
    everify = request.args.get("everify")
    if everify == session['everify']:
        session['everify'] = "Right"
        return redirect(url_for('index'))
    else:
        return "<br><a href = '/email'><b>點擊重新驗證郵箱</b></a>"

@app.route('/')
def index():
    conn = db_connect()
    cursor = conn.cursor()
    cursor.execute("SELECT everify FROM regist")
    conn.close()
    if cursor.execute("SELECT everify FROM regist") == "Right":
        pass
    elif cursor.execute("SELECT everify FROM regist") == "OK":
        session.pop('everify', None)
    else:
        return "您暫未登入， <br><a href = '/login'>" + \
        "<b>點選這裡登入</b></a>" + "<br><a href = '/regist'><b>點選這裡註冊</b></a>"
    return '登入使用者名稱是:' + session['username'] + '<br>' + \
                 "<b><a href = '/logout'>點選這裡登出</a></b>"

@app.route('/login',methods = ['POST', 'GET'])
def login():
    if request.method == 'POST':
        user = request.form['user']
        password = request.form['pass']
        conn = db_connect()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM regist WHERE username = ? AND passname = ?", (user, password))
        result = cursor.fetchone()
        if result:
            cursor.execute("INSERT INTO logged_in (username) VALUES (?)", (user,))
            conn.commit()
            conn.close()
            return "尚未驗證郵箱，是否驗證<br><a href = '/email'>" + \
                "<b>是，點擊驗證郵箱</b></a>" + "<br><a href = '/login'><b>否，不驗證郵箱</b></a>"
        else:
            conn.close()
            return """
                    登入失敗，請確認帳號或密碼！<br>
                    <a href='/login'><b>重新登入</b></a><br>
                    或<br>
                    <a href='/regist'><b>點選進行註冊</b></a>
                """
    else:
        return render_template('index.html')

@app.route('/regist',methods = ['POST', 'GET'])
def regist():
    if request.method == 'POST':
        us = request.form['user']
        pa = request.form['pass']
        em = request.form['email']
        with db_connect() as con:
            cur = con.cursor()
            cur.execute("INSERT INTO regist (username, passname, email) VALUES (?,?,?)", (us, pa, em))
            con.commit()
        return "<b>註冊成功</b>" + "<br><a href = '/email'><b>點擊驗證郵箱</b></a>"
    else:
        return render_template('index2.html')

@app.route('/logout')
def logout():
   # remove the username from the session if it is there
   conn = db_connect()
   cursor = conn.cursor()
   cursor.execute("DELETE FROM logged_in")
   conn.commit()
   conn.close()
   return redirect(url_for('index'))

@app.route('/init')
def init():
    conn = db_connect(None)
    cursor = conn.cursor()
    cursor.execute("CREATE DATABASE IF NOT EXISTS database")
    conn.database = "regist" # 切換目錄
    print ("Opened database successfully")
    cursor.execute('CREATE TABLE regist (username TEXT, passname TEXT, email TEXT, everify TEXT)')
    conn.commit()  # 寫入
    print ("Table created successfully")
    conn.close()
    cursor.execute("CREATE TABLE IF NOT EXISTS logged_in (username TEXT)")
    return "資料庫新增成功"

if __name__ == '__main__':
    app.run(debug=True) # http://127.0.0.1:5000