# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 12:57:51 2021

@author: Alvin
"""

from flask import Flask
app = Flask(__name__)

@app.route('/hello/<name>')
def hello_name(name):
    return 'Hello %s!' % name

if __name__ == '__main__':
    app.run(debug = True)


'''
from flask import Flask
app = Flask(__name__)


@app.route('/hello/<name>')
def show_hello(name):
    return 'hello %s' % name

@app.route('/page/<path:url>')
def show_url(url):
    return 'url %s' % url

@app.route('/blog/<int:postID>')
def show_blog(postID):
    return 'Blog Number %d' % postID

@app.route('/rev/<float:revNo>')
def revision(revNo):
    return 'Revision Number %f' % revNo

if __name__ == '__main__':
    app.run()
'''