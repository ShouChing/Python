# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 12:57:51 2021

@author: Alvin
"""

from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def student():
    return render_template('student.html')

@app.route('/result',methods = ['POST', 'GET'])
def result():
    if request.method == 'POST':
        result = request.form
        return render_template("score_result.html",result = result)

if __name__ == '__main__':
    app.run(debug = True)
    
