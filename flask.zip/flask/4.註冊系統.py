from flask import Flask, render_template, request
import mariadb

app =Flask(__name__)

def db_connect(database="database"):
    return mariadb.connect(host='127.0.0.1', port=3306,
                          user='root', password='0000',
                          database=database)

@app.route('/enternew')
def new_student():
    return render_template('student2.html')

@app.route('/addrec',methods = ['POST', 'GET'])
def addrec():
    if request.method == 'POST':
       try:
          nm = request.form['nm'].strip()
          addr = request.form['add'].strip()
          city = request.form['city'].strip()
          pin = request.form['pin'].strip()
          with db_connect() as con:
             cur = con.cursor()
             cur.execute("INSERT INTO students (name,addr,city,pin) VALUES (?,?,?,?)",(nm,addr,city,pin))
             con.commit()
             msg = "Record successfully added"
       except:
          con.rollback()
          msg = "error in insert operation"
       finally:
          return render_template("result2.html",msg = msg)

@app.route('/list')
def list():
    con = db_connect()
    cur = con.cursor()
    cur.execute("select * from students")
    rows = cur.fetchall()
    return render_template("list.html",rows = rows)

@app.route('/')
def home():
    return render_template('home2.html')

@app.route('/init')
def init():
    conn = db_connect(None)
    cursor = conn.cursor()
    cursor.execute("CREATE DATABASE IF NOT EXISTS database")
    conn.database = "database" # 切換目錄
    print ("Opened database successfully")
    cursor.execute('CREATE TABLE students (name TEXT, addr TEXT, city TEXT, pin TEXT)')
    conn.commit()  # 寫入
    print ("Table created successfully")
    conn.close()
    return "資料庫新增成功"

if __name__ == '__main__':
    app.run(debug = True)

