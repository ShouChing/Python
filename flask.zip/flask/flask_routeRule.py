# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 13:24:32 2021

@author: Alvin
"""

from flask import Flask
app = Flask(__name__)

@app.route('/flask')
def hello_flask():
    return 'Hello Flask'

@app.route('/python/')
def hello_python():
    return 'Hello Python'

if __name__ == '__main__':
    app.run()