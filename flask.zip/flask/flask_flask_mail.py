

from flask import Flask
from flask_mail import Mail, Message

app =Flask(__name__)

app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'jack86057@gmail.com'
app.config['MAIL_PASSWORD'] = 'tlycjaypjsmwiyer'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
mail = Mail(app)

@app.route("/")
def index():
    msg = Message('Hello', sender = 'jack86057@gmail.com', recipients = ['jack86057@gmail.com','fcaibialvin@gmail.com'])
    msg.body = "Hello Flask message sent from Flask-Mail 2025/1/14"
    # msg.html =
    mail.send(msg)
    return "Sent"

if __name__ == '__main__':
    app.run(debug = True)

