# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 12:57:51 2021

@author: Alvin
"""

from flask import Flask, render_template
app = Flask(__name__)

@app.route('/score/<int:score>')
def hello_score(score):
    return render_template('score.html', marks = score)

if __name__ == '__main__':
    app.run(debug = True)
    
