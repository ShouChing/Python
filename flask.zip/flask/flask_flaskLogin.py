
from flask import Flask, request, render_template, url_for, flash, redirect
from 乘法表 import LoginManager, UserMixin, login_user, logout_user, current_user, login_required
#(注意套件載入順序-2.乘法表.py)

# Flask 初始化
app = Flask(__name__)
app.secret_key = ('alvin secret_key')

# Flask-Login 初始化
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.session_protection = "strong"
login_manager.login_view = 'login'
login_manager.login_message = '請證明你有登入'

class User(UserMixin):
    pass


@login_manager.user_loader
def user_loader(user_id):
    if user_id not in users:
        return

    user = User()
    user.id = user_id
    return user


@login_manager.request_loader
def request_loader(request):
    user_id = request.form.get('user_id')
    if user_id not in users:
        return

    user = User()
    user.id = user_id

    # DO NOT ever store passwords in plaintext and always compare password
    # hashes using constant-time comparison!
    user.is_authenticated = (request.form['password'] == users[user_id]['password'])

    return user

# users 使用者清單
users = {'Me': {'password': 'myself'}}

@app.route("/")
def home():
    return render_template("home.html")

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template("login2.html")
    
    user_id = request.form['user_id']
    if (user_id in users) and (request.form['password'] == users[user_id]['password']):
        user = User()
        user.id = user_id
        login_user(user)
        flash(f'{user_id}！歡迎加入Alvin\'s home的行列！')
        return redirect(url_for('from_start'))

    flash('登入失敗了...')
    return render_template('login2.html')

@app.route('/logout')
def logout():
    user_id = current_user.get_id()
    logout_user()
    flash(f'{user_id}！歡迎下次再來！')
    return render_template('login2.html') 

@app.route("/from_start")
@login_required
def from_start():
    return render_template("from_start.html")

            
if __name__ == "__main__":
    app.run()