# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 12:57:51 2021

@author: Alvin
"""

from flask import Flask, render_template
app = Flask(__name__)

@app.route("/")
def index():
    return render_template("static.html")

if __name__ == '__main__':
    app.run(debug = True)
