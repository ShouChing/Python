# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

from flask import Flask, render_template
app = Flask(__name__)

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/from_start")
def from_start():
    return render_template("from_start.html")

if __name__ == '__main__':
    app.run(debug = True)