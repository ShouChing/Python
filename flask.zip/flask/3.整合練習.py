# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 13:24:32 2021

@author: Alvin
"""
from flask import Flask, request, render_template, url_for
import pandas as pd
import matplotlib.pyplot as plt
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from time import sleep
app = Flask(__name__)
app.secret_key = 'Jack secret key'

def stockplot(i):
    # 時間序列，先兩參數，後做排序
    data = pd.read_csv("./static/apple.csv", index_col="Date", parse_dates=True)
    data2 = pd.read_csv("./static/apple(new).csv", index_col="Date", parse_dates=True)
    data3 = pd.concat([data, data2])
    data = data3.sort_index()
    dM = data.loc[f"{i}"].resample('ME')['Close'].mean()
    di = data.loc[f"{i}"].resample('ME')['Close'].mean().index
    plt.bar(di, dM, width=10, label="Year")
    plt.plot(di, dM, color="r", marker="o", label="Year")
    plt.xticks(fontsize=7)
    plt.legend()
    plt.xlabel("Year")
    plt.ylabel("Stock Price")
    plt.savefig(f"./static/bar{i}.png")
    plt.clf()
    # pie
    pie = data.loc[f"{i}"].resample('ME')['Close'].mean()
    season = data.loc[f"{i}"].resample('ME')['Close'].mean().index
    plt.pie(pie, labels=season, autopct="%1.1f%%")
    plt.savefig(f"./static/pie{i}.png")
    plt.clf()

def conv_m(month_number):
    months = ['1 月', '2 月', '3 月', '4 月', '5 月', '6 月', '7 月', '8 月', '9 月', '10 月', '11 月', '12 月']
    return months[int(month_number) - 1]


def numlottery(time_t):
    browser = webdriver.Chrome()
    browser.get("https://www.taiwanlottery.com/lotto/result/super_lotto638")
    browser.find_elements(By.CLASS_NAME, "game-select-item")[1].click()
    browser.find_elements(By.CLASS_NAME, "asterisk-left")[1].click()
    sleep(1)

    # 114/01/07，114/01
    time = time_t.split("/")
    mon = conv_m(time[1])

    r = browser.page_source
    soup = BeautifulSoup(r, 'html.parser')
    # 判別年，定位到該tag，提取data-year屬性
    year = soup.select_one("span.el-date-picker__header-label")['data-year'].split()[0]
    if time[0] < year:
        browser.find_element(By.CLASS_NAME, "el-date-picker__prev-btn").click()
    # 判別月。By.CSS_SELECTOR: "[指定屬性='指定名稱']"
    browser.find_element(By.CSS_SELECTOR, f"[aria-label='{mon}']").click()
    browser.find_element(By.CLASS_NAME, "search-area-btn").click()
    sleep(1)
    # 判別日。點擊完後二次讀取
    r2 = browser.page_source
    soup2 = BeautifulSoup(r2, 'html.parser')
    date = soup2.select("div.period-date")
    # 時間與資料配對
    ballt = {}
    for index, i in enumerate(date):
        if time_t in i.text:
            ball, status = [], True
            for j in soup2.select("div.winner-number-other-container")[index]:
                ball.append(j.text)
            ballt[i.text] = ','.join(ball)
    if ballt is None: print("Date not found")
    browser.quit()
    return ballt

@app.route('/')
def index():
    return "<a href = '/apple'><b>Apple股價查詢</b></a>" + \
            "<br><a href = '/lottery'><b>樂透號碼查詢</b></a>"

@app.route('/apple',methods = ['POST', 'GET'])
def apple():
    if request.method == 'POST':
        stockplot(request.form['user'])
        img1 = url_for('static', filename="bar" + request.form['user'] + ".png")
        img2 = url_for('static', filename="pie" + request.form['user'] + ".png")
        return render_template('IMG.html', name1 = img1, name2 = img2)
    else:
        return render_template('apple.html')

@app.route('/lottery',methods = ['POST', 'GET'])
def lottery():
    if request.method == 'POST':
        result = numlottery(request.form['user'])
        return render_template('lottery_result.html', result=result)
    else:
        return render_template('lottery.html')

if __name__ == '__main__':
    app.run(debug=True) # http://127.0.0.1:5000