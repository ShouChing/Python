

from flask_wtf import Form
from wtforms import TextField, IntegerField, TextAreaField, SubmitField, RadioField, SelectField

from wtforms import validators

#pip install WTForms==2.2.1

class ContactForm(Form):
    name = TextField("學生姓名",[validators.Required("Please enter your name.")])
    Gender = RadioField('性別', choices = [('M','Male'),('F','Female')])
    Address = TextAreaField("地址")

    email = TextField("Email",[validators.Required("Please enter your email address."), validators.Email("Please enter your email address.")])

    Age = IntegerField("年齡")
    language = SelectField('語言', choices = [('cpp', 'C++'), ('py', 'Python')])
    submit = SubmitField("提交")
    
    