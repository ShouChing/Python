# -*- coding: utf-8 -*-
"""
Created on Wed Jun 23 17:21:39 2021

@author: Alvin
"""

from flask import Flask, render_template
app = Flask(__name__)

records = [("1", "a", "aa", "10", "2021/01/01"),
           ("2", "b", "bb", "20", "2021/02/01"),
           ("3", "c", "cc", "30", "2021/03/01"),
           ("4", "d", "dd", "40", "2021/04/01"),
           ("5", "e", "ee", "50", "2021/05/01")]

@app.route("/jinja2_macro")
def jinja2_macro():
    return render_template("jinja2_macro.html", html_records=records)


if __name__ == '__main__':
    app.run(debug = True)
    
