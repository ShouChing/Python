# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 13:24:32 2021

@author: Alvin
"""

from flask import Flask, request, render_template
app = Flask(__name__)

@app.route('/',methods = ['POST', 'GET'])
def login():
    if request.method == 'POST':
        row = request.form['row']
        col = request.form['col']
        list2 = []
        for i in range(1, eval(row) + 1):
            list1 = []
            for j in range(1, eval(col) + 1):
                list1.append(f"{j} * {i} = {i * j:<4}")
            list2.append(list1)
        return render_template('乘法1.html', val = list2)
    else:
        return render_template('乘法2.html')

if __name__ == '__main__':
    app.run(debug=True, host="127.0.0.1", port="8520") # http://127.0.0.1:5000
    

