# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 13:24:32 2021

@author: Alvin
"""

from flask import Flask, request, redirect, render_template
app = Flask(__name__)

@app.route('/login',methods = ['POST', 'GET'])
def login():
    if request.method == 'POST':
        user = request.form['user']
        pass_ = request.form['pass']
        if user == "Jack" and pass_ == "0000":
            return redirect("https://tw.yahoo.com/")
        else:
            return redirect("https://www.google.com/")
    else:
        return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True, host="127.0.0.1", port="8000") # http://127.0.0.1:5000