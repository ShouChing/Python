# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 12:57:51 2021

@author: Alvin
"""

from flask import Flask, render_template, request
app = Flask(__name__)

@app.route("/")
def hello_name():
    h = eval(request.args.get("h")) / 100
    w = eval(request.args.get("w"))
    bmi = w / h ** 2
    if bmi >= 30:
        url = "https://www.ttvc.com.tw/data/images/5_17%E8%82%A5%E8%83%96%E9%A1%9E%E5%9E%8B.jpg"
    elif bmi >= 20:
        url = "https://thumb.ac-illust.com/47/477f40bf8201dff3dbfbc9fd5d4466bd_w.jpeg"
    else:
        url = "https://img.heho.com.tw/wp-content/uploads/2022/01/1643188804.2341.png"
    return render_template('BMI.html', name = url)

if __name__ == '__main__':
    app.run(debug = True) # 記得輸入參數