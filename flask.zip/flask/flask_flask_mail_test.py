
from flask import Flask
from flask_mail import Mail
from flask_mail import Message
#  加入threating
from threading import Thread

app = Flask(__name__)
app.config.update(
    #  hotmail的設置
    MAIL_SERVER='smtp.live.com',
    MAIL_PROT=587,
    MAIL_USE_TLS=True,
    MAIL_USERNAME='Your Hotmail Count',
    MAIL_PASSWORD='Your Hotmail Password'
)
#  記得先設置參數再做實作mail
mail = Mail(app)


@app.route("/message")
def message():
    #  主旨
    msg_title = 'Hello It is Flask-Mail'
    #  寄件者，若參數有設置就不需再另外設置
    msg_sender = 'Send Mail'
    #  收件者，格式為list，否則報錯
    msg_recipients = ['recipient Mail']
    #  郵件內容
    msg_body = 'Hey, I am mail body!'

    send_mail(sender=msg_sender, recipients=msg_recipients, subject=msg_title, context=msg_body)
    
    return 'You Send Message By Flask-Mail'

def send_async_email(app, msg):
    """
    利用多執行緒來處理郵件寄送
    :param app: 實作Flask的app
    :param msg: 實作Message的msg
    :return:
    """
    with app.app_context():
        mail.send(msg)

def send_mail(sender, recipients, subject, context, **kwargs):
    """
    sender:的部份可以考慮透過設置default
    recipients:記得要list格式
    subject:是郵件主旨
    context:郵件內容
    **kwargs:參數
    """
    msg = Message(subject,
                  sender=sender,
                  recipients=recipients)
    msg.body = context

    #  使用多線程
    thr = Thread(target=send_async_email, args=[app, msg])
    thr.start()
    return thr

if __name__ == "__main__":
    app.debug = True
    app.run()
