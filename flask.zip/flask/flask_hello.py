# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 12:57:51 2021

@author: Alvin
"""

from flask import Flask, request, redirect
app = Flask(__name__)

@app.route("/")
def hello():
    h = eval(request.args.get("h"))/100
    w = eval(request.args.get("w"))
    bmi = w/h**2
    if bmi >= 30:
        return redirect("https://www.google.com/")
    elif bmi >= 20:
        return redirect("https://tw.yahoo.com/")
    else:
        return redirect("https://24h.pchome.com.tw/")

if __name__ == "__main__":
    app.run(debug=True,host='127.0.0.1',port='8765')