# -*- coding: utf-8 -*-
"""
Created on Wed Jun 23 17:21:39 2021

@author: Alvin
"""

from flask import Flask, render_template
app = Flask(__name__)

users = [{"username": "我", "url": "我-APP-的名字.herokuapp.com"},
         {"username": "你", "url": "你-APP-的名字.herokuapp.com"}]

@app.route("/jinja2_example")
def jinja2_example():
    return render_template("jinja2_example.html", users=users)


if __name__ == '__main__':
    app.run(debug = True)