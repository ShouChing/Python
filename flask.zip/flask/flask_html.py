from flask import Flask
from flask import render_template #　渲染樣板
# 要把樣板資料夾放在程式相同的層
app = Flask(__name__)

@app.route('/')
def index():
    #路徑不須加 templates
    return render_template(r"alvin.html")

if __name__ == '__main__':
    app.run()