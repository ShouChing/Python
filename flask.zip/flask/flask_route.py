# -*- coding: utf-8 -*-
"""
Created on Mon Jun 21 12:57:00 2021

@author: Alvin
"""

from flask import Flask
app = Flask(__name__)

@app.route("/")
def hello():
    return "Hello Flask!"

@app.route("/apple")
def apple():
    return "I am apple!"

if __name__ == "__main__":
    app.run()