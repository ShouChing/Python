
from flask import Flask, request, render_template, url_for, flash, redirect

# Flask 初始化
app = Flask(__name__)
app.secret_key = 'alvin secret key'

@app.route('/')
def index():
    return render_template('flash.html')

@app.route('/login', methods = ['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != 'admin' or request.form['password'] != 'admin':
            error = 'Invalid username or password. Please try again!'
        else:
            flash('You were successfully logged in')
            return redirect(url_for('index'))
    return render_template('login3.html', error = error)

            
if __name__ == "__main__":
    app.run()