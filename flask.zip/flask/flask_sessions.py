from flask import Flask
from flask import request
from flask import session, redirect, url_for

app = Flask(__name__)
app.secret_key = 'alvin secret key'

@app.route('/')
def index():
    if 'username' in session:
        username = session['username']
        return '登入使用者名稱是:' + username + '<br>' + \
                 "<b><a href = '/logout'>點選這裡登出</a></b>" # 網址
    return "您暫未登入， <br><a href = '/login'></b>點選這裡登入</b></a>"

@app.route('/login', methods = ['GET', 'POST'])
def login():
    if request.method == 'POST':
        session['username'] = request.form['username']
        return redirect(url_for('index'))

    return '''
   <form action = "" method = "post">
      <p><input type ="text" name ="username"/></p>
      <p><input type ="submit" value ="登入"/></p>
   </form>
   '''

@app.route('/logout')
def logout():
   # remove the username from the session if it is there
   session.pop('username', None)
   return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug = True)