from flask import Flask
from flask_uploads import UploadSet, IMAGES, configure_uploads
from flask import request, render_template

# from werkzeug.utils import secure_filename
# from werkzeug.datastructures import  FileStorage

from flask_wtf import FlaskForm
from wtforms import SubmitField
from flask_wtf.file import FileField, FileAllowed, FileRequired

app = Flask(__name__)

app.config['SECRET_KEY'] = 'development'
app.config['UPLOADED_DEF_DEST'] = r'./static/image'
app.config['UPLOADED_DEF_URL'] = '\\static\\image\\'

abc = UploadSet(name='def', extensions=IMAGES)
configure_uploads(app, abc)

class FormUploads(FlaskForm):
    btn_uploads = FileField('uploads', validators=[
        FileAllowed(abc, '只能上傳圖片'),
        FileRequired('圖片是必需的')
    ])
    submit = SubmitField('上傳圖片')


html = '''
<!DOCTYPE html>
<html lang="en">
<h1>測試上傳</h1>
<form method=post enctype=multipart/form-data>
<input type=file name=in_abc>
<input type=submit value=Upload>
</form>
</html>
'''

@app.route('/upload_wtf/', methods=['GET','POST'])
def upload_wtf():
    form = FormUploads()
    if form.validate_on_submit():
        file_name = abc.save(form.btn_uploads.data)
        file_url = abc.url(file_name)
        print(file_name, file_url)
        return render_template('abc.html', form=form, file_url=file_url)
    else:
        file_url=None
    return render_template('abc.html', form=form, file_url = file_url)


@app.route('/uploads/', methods=['GET', 'POST'])
def uploads():
    if request.method == 'POST' and 'in_abc' in request.files:
        filename = abc.save(request.files['in_abc'])
        print(filename)
        file_url = abc.url(filename)
        print(file_url)
    return html


if __name__ == '__main__':
    app.run(debug=True)
    
    