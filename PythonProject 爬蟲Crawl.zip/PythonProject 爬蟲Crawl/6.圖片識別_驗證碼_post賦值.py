import os
import requests
import re
import ddddocr
from bs4 import BeautifulSoup
from PIL import Image
def initial():
    my_headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'}
    url = "https://www.post.gov.tw/post/internet/"
    url_head = url + "SearchZone/index.jsp?ID=130107"
    session = requests.session() # 此次request都算在同一個session
    r = session.get(url_head, headers=my_headers)
    soup = BeautifulSoup(r.text, 'html.parser')
    os.makedirs("郵局驗證碼", exist_ok=True)
    return url, url_head, session, soup, my_headers
def pay(city, area, street):
    while True:
        url, url_head, session, soup, my_headers = initial()
        list_v = soup.select('div.ConditionSearchContainer input')[0].get('value')
        list_type = soup.select('div.ConditionSearchContainer input')[1].get('value')
        first_view = soup.select('div.ConditionSearchContainer input')[2].get('value')
        vkey = soup.select('div.ConditionSearchContainer input')[3].get('value')
        check = reg(url, soup, my_headers) # 驗證碼識別
        payload = {'list': list_v,         # 隱藏表單
                   'list_type': list_type,
                   'firstView': first_view,
                   'vKey': vkey,
                   'city_zip6': city,
                   'cityarea_zip6': area,
                   'street_zip6': street,
                   'checkImange_zip6': check,
                   'Submit': '查詢'}
        r2 = session.post(url_head, data=payload, headers=my_headers)
        if r2.status_code == 200:
            if "驗證碼輸入錯誤" in r2.text:
                print("驗證碼錯誤，重試一遍")
                continue
            soup2 = BeautifulSoup(r2.text, 'html.parser')
            res = soup2.select('table.TableStyle_02.rwd-table td')
            for res in res:
                if re.findall(r'^\d{6}$', res.text):
                    print("\n"+res.text,end=" ")
                else:
                    print(res.text, end=" ")
            break
def reg(url,soup,my_headers): # 辨識圖片
    ocr = ddddocr.DdddOcr()
    pic_url = soup.select_one('table.captcha-table img').get('src')
    rp = requests.get(url+pic_url[3:], headers=my_headers)
    if rp.status_code == 200:
        name = re.findall(r'checkImage\d+', pic_url)[0] + ".png"
        with open("郵局驗證碼"+"/"+name, "wb") as fw: # 存取圖片
            for fp in rp:
                fw.write(fp)
        # with open("郵局驗證碼/" + name, "rb") as image:
        #     image = image.read()
        image = Image.open("郵局驗證碼"+"/"+name).convert('L')
        return ocr.classification(image)

city = input("城市:")
area = input("區域:")
street = input("街道:")
pay(city, area, street)