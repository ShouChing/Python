from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from time import sleep
browser=webdriver.Chrome()

def conv_m(month_number):
    months = ['1 月', '2 月', '3 月', '4 月', '5 月', '6 月', '7 月', '8 月', '9 月', '10 月', '11 月', '12 月']
    return months[int(month_number) - 1]

def lottery(time_t):
    browser.get("https://www.taiwanlottery.com/lotto/result/super_lotto638")
    browser.find_elements(By.CLASS_NAME, "game-select-item")[1].click()
    browser.find_elements(By.CLASS_NAME, "asterisk-left")[1].click()
    sleep(1)

    # 114/01/07，114/01
    time = time_t.split("/")
    mon = conv_m(time[1])

    r = browser.page_source
    soup = BeautifulSoup(r, 'html.parser')
    # 判別年，定位到該tag，提取data-year屬性
    year = soup.select_one("span.el-date-picker__header-label")['data-year'].split()[0]
    if time[0] < year:
        browser.find_element(By.CLASS_NAME, "el-date-picker__prev-btn").click()
    # 判別月。By.CSS_SELECTOR: "[指定屬性='指定名稱']"
    browser.find_element(By.CSS_SELECTOR, f"[aria-label='{mon}']").click()
    browser.find_element(By.CLASS_NAME, "search-area-btn").click()
    sleep(1)
    # 判別日。點擊完後二次讀取
    r2 = browser.page_source
    soup2 = BeautifulSoup(r2, 'html.parser')
    date = soup2.select("div.period-date")
    # 時間與資料配對
    for index, i in enumerate(date):
        if time_t in i.text:
            ball = []
            for j in soup2.select("div.winner-number-other-container")[index]:
                ball.append(j.text)
            print(i.text+": ",",".join(ball))
lottery(input("請輸入要查詢日期(yyy/mm/dd): "))
browser.quit()