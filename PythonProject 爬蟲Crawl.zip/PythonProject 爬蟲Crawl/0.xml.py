
import xml.etree.ElementTree as ET


def open_xml():
    tree = ET.parse("../PythonProject_20241207/sample.xml")
    # print(tree)

    root = tree.getroot()
    # print(root)

    # print(root.tag)
    # print(root.attrib)


    for item in root:
        # print(item.tag)
        # print(item.attrib)
        # print(item.text)
        '''
        <Element 'Col1' at 0x000001F468953540>
        Col1
        {'name': 'DTime'}
        2023-05-22 15:00:00
        '''
    '''跟.findall一樣
    for item in root.iter("Col1"):
        print(item)
        print(item.tag)
        print(item.attrib)
        print(item.text)
    '''
    '''
    for item in root.findall("Col1"):
        print(item)
        print(item.tag)
        print(item.attrib)
        print(item.text)
    '''

    # print("root[0].text=>", root[0].text)

    print(root.find("Col1").text)


if __name__ == '__main__':
    open_xml()

