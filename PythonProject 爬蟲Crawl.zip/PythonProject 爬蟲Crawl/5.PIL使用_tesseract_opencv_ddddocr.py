from PIL import Image
import pytesseract
import ddddocr
pytesseract.pytesseract.tesseract_cmd=r'C:\Program Files\Tesseract-OCR\tesseract.exe'
img = Image.open('./CaptchaImage.jpg') #./表這一層
img = img.convert("L")
# img.show()
ans = pytesseract.image_to_string(img,config ='--psm 6')
print(ans)
print(ddddocr.DdddOcr().classification(img))
