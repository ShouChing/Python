from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
browser=webdriver.Chrome()
url = "https://www.ptt.cc"
url_head = url + "/bbs/Gossiping/index.html"
time = input("請輸入所需時間~今天的資料: ") # 1/07
def ptt():
    while True:
        global url_head # 宣告後，確保在函數內部可以修改這個全局變數
        browser.get(url_head) # 自動轉.txt
        r = browser.page_source
        # 切割完後BeautifulSoup會自動處理，變數要str所以用.text
        soup = BeautifulSoup(r.split("r-list-sep")[0], 'html.parser')
        # .select('.title')可不輸入name；如果是id則是.select('#h1')
        title = soup.select('div.title')
        link = soup.select('div.title a')
        date = soup.select('div.date')
        # 上頁，標籤<a class="btn wide">，代表有兩個class
        url_head = url + soup.select('a.btn.wide')[1].get('href')
        for i, j, d in zip(title[::-1], link[::-1], date[::-1]):
            if "Re:" in i.text or "刪除)" in i.text:
                continue
            if d.text.strip() != time: return
            try:
                browser.get(url + j.get('href'))
                r2 = browser.page_source
                soup2 = BeautifulSoup(r2, 'html.parser')
                # .select()返回所有匹配span.article-meta-value的元素作為列表
                cut = soup2.select('span.article-meta-value')[3]
                soup3 = BeautifulSoup(r2.split(str(cut))[1].split('<span class="f2')[0], 'html.parser')
                print(i.text.strip(),d.text.strip()+"\n"+soup3.text.strip()+"\n") # sep=" "
            except:
                pass
browser.get("https://www.ptt.cc/ask/over18")
browser.find_element(By.CLASS_NAME, 'btn-big').click()
ptt()
browser.quit() # webdriver.Chrome()在函數內，不能放外面