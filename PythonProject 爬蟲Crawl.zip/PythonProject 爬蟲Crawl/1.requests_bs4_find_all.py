import requests
from bs4 import BeautifulSoup
# ?連結網址跟參數q，多個參數用&
r = requests.get("https://www.google.com/search?q=apple")
if r.status_code == 200:
    # r.text半結構化資料(混合)，soup是結構化資料
    soup = BeautifulSoup(r.text,'html.parser')
    print(soup.title.string)
    for i in soup.find_all('title'):
        print(i.string)
    for i in soup.find_all('a'):
        print(i.get('href'))

# 兩次BeautifulSoup()_.find().get()_zip
url = "https://www.ithome.com.tw/"
r = requests.get(url)
if r.status_code == 200:
    soup = BeautifulSoup(r.text,"html.parser")
    # .find_all(name=,id=_,class_=_)也可以找id
    # .find_all("p", "title")，class_可省略
    # .find_all("p", attrs={"class":"title"})，attrs自訂屬性
    title = soup.find_all("p", class_="title")
    time = soup.find_all("p", class_="post-at")
    for title,time in zip(title,time): # zip配對
        soup2 = BeautifulSoup(str(title),"html.parser")
        # .string內層文字不會印出
        print(title.text,time.text,    # get只能單行，find_all型態是set
              url + soup2.find("a").get("href"))
        # 方法二，有可能失效
        print("方法二: " + url + title.a.get("href"))