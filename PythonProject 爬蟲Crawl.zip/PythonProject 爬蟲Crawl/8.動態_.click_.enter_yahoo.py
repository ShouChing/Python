from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
browser=webdriver.Chrome()
browser.get("https://tw.search.yahoo.com/")
browser.find_element(By.ID, "yschsp").send_keys("apple")
browser.find_element(By.ID, "yschsp").send_keys(Keys.ENTER)
r = browser.page_source
print(r)
browser.find_element(By.ID, "yschsp").clear()
browser.find_element(By.ID, "yschsp").send_keys("banana")
browser.find_element(By.ID, "yschsp").send_keys(Keys.ENTER)
r = browser.page_source
print(r)

# 網址2_.click使用
browser.get("https://tw.yahoo.com/")
browser.find_element(By.ID, "header-search-input").send_keys("orange")
browser.find_element(By.ID, "header-desktop-search-button").click()
r = browser.page_source
print(r)
browser.quit() # 會關掉驅動，不行