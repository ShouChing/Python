import os
import re
import requests
import ddddocr
from bs4 import BeautifulSoup
from PIL import Image
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
browser=webdriver.Chrome()

def pay(city, area, street):
    os.makedirs("郵局驗證碼", exist_ok=True)
    url = "https://www.post.gov.tw/post/internet/"
    url_head = url + "SearchZone/index.jsp?ID=130107"
    browser.get(url_head)
    r = browser.page_source
    soup = BeautifulSoup(r, 'html.parser')
    while True:
        check = reg(url, soup)
        # 找尋名字的值。Select只能用在Tag為select上面
        Select(browser.find_element(By.NAME, 'city_zip6')).select_by_visible_text(city)
        Select(browser.find_element(By.NAME, 'cityarea_zip6')).select_by_visible_text(area)
        Select(browser.find_element(By.NAME, 'street_zip6')).select_by_visible_text(street)
        browser.find_element(By.ID, 'checkImange_zip6').send_keys(check)
        browser.find_element(By.CLASS_NAME, 'Submit_1').click()
        # try:
        #     browser.switch_to.alert.accept()
        #     print("驗證碼錯誤，重試一遍")
        #     continue
        # except:
        #     pass
        # r2 = browser.page_source
        try:# 跳出錯誤框若繼續執行r2進入except，頁面會重新加載
            r2 = browser.page_source
        except:
            print("驗證碼錯誤，重試一遍")
            continue
        soup2 = BeautifulSoup(r2, 'html.parser')
        res = soup2.select('table.TableStyle_02.rwd-table td')
        for res in res:
            if re.findall(r'^\d{6}$', res.text):
                print("\n"+res.text,end=" ")
            else:
                print(res.text, end=" ")
        break
def reg(url,soup): # 辨識圖片
    ocr = ddddocr.DdddOcr()
    pic_url = soup.select_one('table.captcha-table img').get('src')
    rp = requests.get(url + pic_url[3:])
    if rp.status_code == 200:
        name = re.findall(r'checkImage\d+', pic_url)[0] + ".png"
        with open("郵局驗證碼" + "/" + name, "wb") as fw:  # 存取圖片
            for fp in rp:
                fw.write(fp)
        image = Image.open("郵局驗證碼" + "/" + name).convert('L')
        return ocr.classification(image)

city = input("城市:")
area = input("區域:")
street = input("街道:")
pay(city, area, street)
browser.quit()