import requests
from bs4 import BeautifulSoup
payload = {"from":"/bbs/Gossiping/M.1725445765.A.E50.html","yes":"yes"}
session = requests.session() # 此次request都算在同一個session
session.post("https://www.ptt.cc/ask/over18", payload)
url = "https://www.ptt.cc"
url_head = url + "/bbs/Gossiping/index.html"
n = 10
time = input("請輸入所需時間~今天的資料:") # 1/07
def ptt():
    while True:
        global url_head # 宣告後，確保在函數內部可以修改這個全局變數
        r = session.get(url_head) # 變成requests.session().get()
        if r.status_code == 200:
            # 切割完後BeautifulSoup會自動處理，BeautifulSoup參數要str所以用.text
            soup = BeautifulSoup(r.text.split("r-list-sep")[0], 'html.parser')
            # .select('.title')會找所有title類別的元素；如果是id則是.select('#h1')
            title = soup.select('div.title')
            link = soup.select('div.title a')
            date = soup.select('div.date')
            # 上頁，<a class="btn wide">，btn、wide為標籤a的兩個class
            url_head = url + soup.select('a.btn.wide')[1].get('href')
            for i, j, d in zip(title[::-1], link[::-1], date[::-1]):
                if "Re:" in i.text or "刪除)" in i.text:
                    continue
                if d.text.strip() != time: return
                try:
                    r2 = session.get(url + j.get('href'))
                    soup2 = BeautifulSoup(r2.text, 'html.parser')
                    # .select()返回所有匹配span.article-meta-value的元素作為列表
                    cut = soup2.select('span.article-meta-value')[3]
                    soup3 = BeautifulSoup(r2.text.split(str(cut))[1].split('<span class="f2')[0], 'html.parser')
                    print(i.text.strip(),d.text.strip()+"\n"+soup3.text.strip()+"\n") # sep=" "
                except requests.exceptions.HTTPError:
                    pass
ptt()