import pandas as pd
import requests
from bs4 import BeautifulSoup
my_headers = {'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'}
n = 5
key = input("請輸入關鍵字搜尋:")
titlelist, keylist, typelist, linklist= [], [], [], []
for p in range(n):
    r = requests.get(f"https://www.google.com/search?q={key}&start={p*10}", headers=my_headers)
    if r.status_code == 200:
        soup = BeautifulSoup(r.text,'html.parser')
        title = soup.select('h3.LC20lb.MBeuO.DKV0Md')
        link = soup.select('div.yuRUbf a')
        for i,j in zip(title,link):
            titlelist.append(i.text)
            keylist.append(key)
            typelist.append("Google")
            linklist.append(j.get('href'))
    r2 = requests.get(f"https://tw.search.yahoo.com/search?p={key}&b={p*7+1}", headers=my_headers)
    if r2.status_code == 200:
        soup = BeautifulSoup(r2.text,'html.parser')
        title = soup.select('h3.title.tc a')
        for i in title:
            title2 = BeautifulSoup(i.get('aria-label'), "html.parser")
            titlelist.append(title2.text)
            keylist.append(key)
            typelist.append("Yahoo")
            linklist.append(i.get('href'))
data = pd.DataFrame({'Title':titlelist,'Key':keylist,"Type":typelist,"Link":linklist})
data.to_csv('SearchEngine.csv')