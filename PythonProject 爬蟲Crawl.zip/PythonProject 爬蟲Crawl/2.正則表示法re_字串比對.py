import re
while True:
    input1 = input("UID:")
    cond = re.findall(r"^[A-Z][12]\d{8}", input1)
    if cond:
        print(cond[0])
        break
while True:
    input1 = input("Phone number:")
    cond = re.findall(r"^09\d{8}", input1)
    if cond:
        print(cond[0])
        break
while True:
    input1 = input("Email:")
    cond = re.findall(r"^[\w\.-]+@[\w\.-]+\.[a-z]+$", input1)
    if cond:
        print(cond[0])
        break