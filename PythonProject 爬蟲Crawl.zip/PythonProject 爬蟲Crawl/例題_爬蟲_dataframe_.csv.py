import pandas as pd
import requests
from bs4 import BeautifulSoup
n, titles, links, times, types = 5, [], [], [], []
classes = ["politics","society","arts-culture"]
for c in classes:
    for i in range(1,n+1):
        url = f"https://www.thenewslens.com/category/{c}?page={i}"
        r = requests.get(url)
        if r.status_code == 200:
            soup = BeautifulSoup(r.text,"html.parser")
            title = soup.find_all("a", class_="multiline-ellipsis-2 text-link")
            time = soup.find_all("time", class_="small time")
            # 標題是單行
            for title,time in zip(title,time):
                links.append(title.get("href").strip())
                titles.append(title.string.strip())
                times.append(time.string.strip())
                types.append(soup.find("h1", class_="headine headine-lg page-title").string.strip())
                # types.append(soup.select_one('h1.headine.headine-lg.page-title').string.strip())
data = pd.DataFrame({"Title": titles,"Link": links,"Time": times,"Type": types})
data.to_csv("theNewsLens.csv")