# -*- coding: utf-8 -*-
"""
Created on Fri Jun 11 06:54:07 2021

@author: Alvin
"""

cno = "零一二三四五六七八九"

# 平面點類別
class Point :
    def __init__( self , x = 0 , y = 0 ) : 
        self.x , self.y = x , y
    
    def __str__( self ) : 
        return "({},{})".format(self.x,self.y)
        # 如果是由自訂的__str__返回值，那值就屬於該類別(Point)型態
        # 反之不自訂的__str__，那也只能回傳python內建型態
# 多邊形類別
class Polygon :
    def __init__( self , pts ) : 
        self.pts = pts
    
    def __str__( self ) : 
        return " ".join( [ str(pt) for pt in self.pts ] )
    
    def name( self ) : 
        return cno[len(self.pts)] + "邊形"

# 三角形：使用多邊形的起始設定方法
class Triangle(Polygon) :
    def __init__( self , p1 , p2 , p3 ) : 
        Polygon.__init__(self,[p1,p2,p3])
    
    def name( self ) : 
        return "三角形"
    
if __name__ == "__main__" :
    # 定義四個點與兩個物件
    p1 , p2 , p3 , p4 = Point(0,0) , Point(1,0) , Point(0,2) , Point(-2,2)
    # __init__不用return也會自動回傳值，所以poly有值不是因為__str__同時poly也不是字串
    # 有用到print才會自動調用__str__
    poly , tri = Polygon([p1,p2,p3,p4]) , Triangle(p1,p2,p3)
    # [ poly , tri ]: 一個有兩元素的list
    for foo in [ poly , tri ] : print(foo.name(),foo)
    # Python 的 魔法方法 (__str__) 會在 str() 運行時自動查找並執行對應類別的 __str__ 方法
    # str(foo)->Polygon->__str__->str(pt)，pt是point物件，str會先搜索該物件是否有自訂__str__方法
    # 當類別未定義__str__方法，會使用預設來自object類別的__str__方法，返回物件的類別和記憶體位址
    # Python的內建類型(類別)都有內建__str__方法輸出正確字串
