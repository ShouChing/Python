# -*- coding: utf-8 -*-
"""
Created on Fri Jun 11 06:54:07 2021

@author: Alvin
"""

class Base:
    pass

class Derived1(Base):
    pass

class Derived2(Derived1):
    pass
    
