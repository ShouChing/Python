# -*- coding: utf-8 -*-
"""
Created on Mon May 31 08:08:42 2021

@author: Alvin
"""

import Point
p1 = Point.Point()

