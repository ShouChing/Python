# -*- coding: utf-8 -*-
"""
Created on Fri Jun 11 06:32:24 2021

@author: Alvin
"""

# A 程式區塊 ：開發完成程式區塊
print("A")
pass

if __name__ == "__main__" : # 判斷 foo.py 是否為起始執行檔
    # B 程式區塊：測試用程式區塊
    print("B")
    pass


