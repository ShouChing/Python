# -*- coding: utf-8 -*-
"""
Created on Fri Jun 11 06:40:18 2021

@author: Alvin
"""

def foo() : 
    print("foo" )

print("foo:" , __name__ )
