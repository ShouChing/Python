import random
class Num:
    def __init__(self):
        self.list1 = []
        self.start = 0
        self.end = 0
        self.count = 0
    def generator(self):
        while len(self.list1) < self.count:
            num = random.randint(self.start, self.end)
            if num not in self.list1:
                self.list1.append(num)
        return self.list1 # 這邊是使用list的__str__方法
        # 如果是由自訂的__str__返回值，那值就屬於該類別型態
class Numstat(Num):
    def sum_n(self):
        # 如果list1被設為value_product的區域變數，那麼就無法繼承到這邊
        return sum(self.list1)
    def ave_n(self):
        if self.count == 0:
            return 0
        else:
            return self.sum_n()/self.count
        # 類別方法要Numstat.method，內部調用物件方法就self.method
    def generator(self):
        # 如果方法同名，可用super()
        print(super().generator()) # 返回self.list1
        print(self.sum_n())
        print(self.ave_n())
ans = Numstat()
print("請輸入隨機範圍:")
ans.start = eval(input("最小值: "))
ans.end = eval(input("最大值: "))
print("請輸入數字個數:")
ans.count = eval(input())
ans.generator()