# -*- coding: utf-8 -*-
"""
Created on Fri Jun 11 06:32:24 2021

@author: Alvin
"""

import foo

print(__name__)       # 輸出：_ _main_ _
print(foo.__name__)   # 輸出：foo


