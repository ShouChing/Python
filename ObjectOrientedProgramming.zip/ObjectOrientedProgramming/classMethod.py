# -*- coding: utf-8 -*-
"""
Created on Wed Dec 21 12:38:44 2022

@author: teacher
"""

class Fraction :
    
    # 起始方法：用以建構物件，不需回傳
    def __init__ ( self , n = 0 , d = 1 ) :
        self.num , self.den = n , d
    #字串表示方法：設定物件的「字串」輸出樣式
    def __str__ ( self ) :
        if self.den == 1 :
            return str(self.num)
        else :
            return str(self.num) + '/' + str(self.den)
    
    # 由字串轉換來的分數
    @classmethod
    def fromstr(cls, fstr ) :
        if fstr.isdigit():
            num ,den = int(fstr) , 1
        else:
            num, den = map( int , fstr.split('/') )
        return cls(num, den)
    
    # 帶分數型式
    @classmethod
    def mixed_fraction(cls ,a = 0 ,n = 0 ,d = 1 ) :
        num , den = a * d + n , d
        return cls(num,den)
    
    # 分數資料說明
    @classmethod
    def data_doc(cls):
        return "num:分子 , den:分母"

# 以下三個 Fraction 被自動設為類別方法的第一個參數
a = Fraction.fromstr("5")
b = Fraction.fromstr("4/7")
c = Fraction.mixed_fraction(2,3,4)
# 印出：5 4/7 11/4
print( a , b , c )
# 印出：num:分子 , den:分母
print( Fraction.data_doc() )    
