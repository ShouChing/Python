# -*- coding: utf-8 -*-
"""
Created on Fri Jun 11 06:51:11 2021

@author: Alvin
"""

# A 程式區塊 ：開發完成程式區塊
print("A")
pass

# 定義類似 C 語言的主函式
def main() :
    print("main")
    pass

if __name__ == "__main__" :
    # B 程式區塊：測試用程式區塊
    main()
