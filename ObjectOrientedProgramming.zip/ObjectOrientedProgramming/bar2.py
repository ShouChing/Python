# -*- coding: utf-8 -*-
"""
Created on Fri Jun 11 06:43:16 2021

@author: Alvin
"""

import foo

print("bar:" , foo.__name__)
print("bar:" , __name__ )
